import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { Invoice, InvoiceType, Product, Account, SalesStaff, Territory, UserProfile, InvoiceItem } from '../types';
import { ShoppingBag, Plus, Trash2, Save, Printer, X, Edit, Search, Calendar, Filter, RotateCcw, Download, Factory, Eye } from 'lucide-react';
import {
  printReportDirect,
  downloadPdfFromReportHtml
} from '../utils/reportPrinter';
import { formatDate } from '../utils/dateUtils';

export const InvoicesComponent: React.FC<{
  currentUser: UserProfile;
  defaultType?: InvoiceType;
  initialInvoiceNo?: string;
}> = ({
  currentUser,
  defaultType = 'SALES_CREDIT',
  initialInvoiceNo
}) => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [staffList, setStaffList] = useState<SalesStaff[]>([]);
  const [territories, setTerritories] = useState<Territory[]>([]);
  const [companyProfile, setCompanyProfile] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<InvoiceType>(defaultType);
  const [selectedPrintInvoice, setSelectedPrintInvoice] = useState<Invoice | null>(null);
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);

  // Date-wise Search and Filter states
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');
  const [searchKeyword, setSearchKeyword] = useState('');

  // Form state
  const [invoiceNo, setInvoiceNo] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [accountName, setAccountName] = useState('');
  const [accountSearch, setAccountSearch] = useState('');
  const [productSearches, setProductSearches] = useState<{ [index: number]: string }>({});
  const [salesStaff, setSalesStaff] = useState('');
  const [territory, setTerritory] = useState('');
  const [reason, setReason] = useState('');
  const [remarks, setRemarks] = useState('');
  const createEmptyItem = (): InvoiceItem => ({
    productId: '',
    productName: '',
    quantity: 1,
    unit: (activeTab === 'SALES_MAUND' || activeTab === 'PURCHASE_MAUND') ? 'Maund' : 'Bag',
    rate: 0,
    discountType: 'PERCENT',
    discount: 0,
    discountAmount: 0,
    amount: 0,
    packSize: '40kg',
    scheme: 'CASH SALE',
    lotNo: '',
    gstPercent: 0,
    gstAmount: 0,
    quantityOut: 0,
    quantityIn: 0,
    description: ''
  });

  const [items, setItems] = useState<InvoiceItem[]>([createEmptyItem()]);

  useEffect(() => {
    loadData();
  }, [activeTab]);

  useEffect(() => {
    if (initialInvoiceNo && invoices.length > 0) {
      const found = invoices.find(i => i.invoiceNo === initialInvoiceNo);
      if (found) {
        setSelectedPrintInvoice(found);
      }
    }
  }, [initialInvoiceNo, invoices]);

  const loadData = async () => {
    const invs = await db.getInvoices();
    const prods = await db.getProducts();
    const accs = await db.getAccounts();
    const staff = await db.getSalesStaff();
    const terrs = await db.getTerritories();
    const profile = await db.getCompanyProfile();
    setInvoices(invs.filter(i => i.invoiceType === activeTab));
    setProducts(prods);
    setAccounts(accs);
    setStaffList(staff);
    setTerritories(terrs);
    setCompanyProfile(profile);
    setEditingInvoice(null);
    setAccountName('');
    setAccountSearch('');
    setProductSearches({});
    const prefix = activeTab === 'PRODUCTION' ? 'PRD' : activeTab.substring(0, 3);
    setInvoiceNo(`${prefix}-${Math.floor(1000 + Math.random() * 9000)}`);
    setItems([createEmptyItem()]);
  };

  const handleProductionQtyChange = (
    index: number,
    field: 'quantityOut' | 'quantityIn',
    val: string | number
  ) => {
    const num = Math.max(0, Number(val) || 0);
    const updated = [...items];
    if (field === 'quantityOut') {
      updated[index].quantityOut = num;
      if (num > 0) {
        updated[index].quantityIn = 0;
      }
      updated[index].quantity = num > 0 ? num : (updated[index].quantityIn || 0);
    } else {
      updated[index].quantityIn = num;
      if (num > 0) {
        updated[index].quantityOut = 0;
      }
      updated[index].quantity = num > 0 ? num : (updated[index].quantityOut || 0);
    }
    setItems(updated);
  };

  const handleProductionDescChange = (index: number, desc: string) => {
    const updated = [...items];
    updated[index].description = desc;
    setItems(updated);
  };

  const buildInvoiceHtml = (inv: Invoice): string => {
    const compName = companyProfile?.companyName || 'AUGUSTA SEED COMPANY';
    const compAddr = companyProfile?.headOfficeAddress || 'UNITED FARM ROAD, GULSHAN-E-ALI BY PASS, SAHIWAL';
    const compPhone = companyProfile?.phone || companyProfile?.mobile || '03023576036';
    const logoUrl = companyProfile?.logoUrl || '/logoittehad.png';

    if (inv.invoiceType === 'PRODUCTION') {
      const totalOut = inv.items.reduce((s, it) => s + Number(it.quantityOut || 0), 0);
      const totalIn = inv.items.reduce((s, it) => s + Number(it.quantityIn || 0), 0);

      const rows = inv.items
        .map(
          (it, idx) => `
        <tr>
          <td style="text-align:center;font-family:monospace;font-weight:bold;">${idx + 1}</td>
          <td style="font-weight:bold;color:#111827;">${it.productName}</td>
          <td style="color:#4b5563;">${it.description || '-'}</td>
          <td style="text-align:center;">${it.unit || 'Bag'} (${it.packSize || '40kg'})</td>
          <td style="text-align:right;font-family:monospace;font-weight:bold;color:#b91c1c;background:#fef2f2;">
            ${Number(it.quantityOut || 0) > 0 ? Number(it.quantityOut).toLocaleString() : '-'}
          </td>
          <td style="text-align:right;font-family:monospace;font-weight:bold;color:#065f46;background:#f0fdf4;">
            ${Number(it.quantityIn || 0) > 0 ? Number(it.quantityIn).toLocaleString() : '-'}
          </td>
        </tr>
      `
        )
        .join('');

      return `
        <div>
          <div style="display:flex;align-items:center;justify-content:space-between;border-bottom:2.5px solid #064e3b;padding-bottom:10px;margin-bottom:12px;">
            <div style="display:flex;align-items:center;gap:12px;">
              <img src="${logoUrl}" style="width:54px;height:54px;object-fit:contain;" alt="Logo" onerror="this.style.display='none'" />
              <div>
                <h1 style="margin:0;font-size:19px;font-weight:900;color:#064e3b;text-transform:uppercase;letter-spacing:0.5px;">${compName}</h1>
                <div style="font-size:11px;color:#374151;margin-top:2px;">${compAddr} &bull; PH: ${compPhone}</div>
              </div>
            </div>
            <div style="text-align:center;border:2px solid #064e3b;background:#f0fdf4;padding:6px 14px;border-radius:6px;">
              <span style="font-weight:900;color:#064e3b;font-size:13px;text-transform:uppercase;letter-spacing:1px;">PRODUCTION ORDER / VOUCHER</span>
            </div>
          </div>

          <div style="display:flex;justify-content:space-between;margin-bottom:12px;font-size:11.5px;line-height:1.5;">
            <div>
              <div><strong>DEPARTMENT / UNIT:</strong> <span style="font-weight:bold;color:#064e3b;text-transform:uppercase;">${inv.accountName || 'Seed Processing & Production Unit'}</span></div>
              <div><strong>SUPERVISOR / INCHARGE:</strong> <span style="text-transform:uppercase;">${inv.salesStaff || 'Production Manager'}</span></div>
              ${inv.remarks ? `<div><strong>REMARKS / BATCH:</strong> ${inv.remarks}</div>` : ''}
            </div>
            <div style="text-align:right;">
              <div><strong>PRODUCTION NO:</strong> <span style="font-family:monospace;font-weight:bold;color:#064e3b;">${inv.invoiceNo}</span></div>
              <div><strong>DATE:</strong> <span style="font-family:monospace;">${formatDate(inv.date)}</span></div>
              <div><strong>PLANT / LOCATION:</strong> <span style="text-transform:uppercase;">${inv.territory || 'MAIN PROCESSING PLANT'}</span></div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th style="width:40px;text-align:center;">#</th>
                <th>Product / Seed Item</th>
                <th>Description / Batch Particulars</th>
                <th style="width:110px;text-align:center;">Unit & Pack</th>
                <th style="width:130px;text-align:right;background:#991b1b;color:white;">Qty Out (Minus Stock)</th>
                <th style="width:130px;text-align:right;background:#065f46;color:white;">Qty In (Plus Stock)</th>
              </tr>
            </thead>
            <tbody>
              ${rows}
            </tbody>
            <tfoot>
              <tr>
                <td colspan="4" style="text-align:right;font-weight:bold;">Total Production Quantities:</td>
                <td style="text-align:right;font-family:monospace;font-weight:bold;color:#b91c1c;background:#fee2e2;">${totalOut.toLocaleString()}</td>
                <td style="text-align:right;font-family:monospace;font-weight:bold;color:#065f46;background:#dcfce7;">${totalIn.toLocaleString()}</td>
              </tr>
            </tfoot>
          </table>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:16px;font-size:11px;">
            <div style="border:1px solid #d1d5db;background:#fef2f2;padding:10px 14px;border-radius:6px;text-align:center;">
              <div style="font-size:10px;font-weight:800;color:#991b1b;text-transform:uppercase;">TOTAL RAW MATERIALS CONSUMED (OUT)</div>
              <div style="font-size:24px;font-weight:900;color:#b91c1c;font-family:monospace;margin-top:4px;">${totalOut} Units</div>
            </div>
            <div style="border:1px solid #d1d5db;background:#f0fdf4;padding:10px 14px;border-radius:6px;text-align:center;">
              <div style="font-size:10px;font-weight:800;color:#065f46;text-transform:uppercase;">TOTAL FINISHED SEED PRODUCED (IN)</div>
              <div style="font-size:24px;font-weight:900;color:#064e3b;font-family:monospace;margin-top:4px;">${totalIn} Units</div>
            </div>
          </div>

          <div style="margin-top:35px;padding-top:14px;border-top:1px solid #9ca3af;display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;font-size:10.5px;text-align:center;">
            <div>
              <div style="border-top:1.5px solid #111827;padding-top:4px;font-weight:bold;">Prepared By (${inv.createdBy || 'Staff'})</div>
            </div>
            <div>
              <div style="border-top:1.5px solid #111827;padding-top:4px;font-weight:bold;">Production Supervisor</div>
            </div>
            <div>
              <div style="border-top:1.5px solid #111827;padding-top:4px;font-weight:bold;">Quality Control Incharge</div>
            </div>
            <div>
              <div style="border-top:1.5px solid #111827;padding-top:4px;font-weight:bold;">Authorized Manager</div>
            </div>
          </div>

          <div style="text-align:center;font-size:10px;color:#6b7280;margin-top:20px;border-top:1px dashed #d1d5db;padding-top:6px;">
            ${compName} &bull; ${compAddr} &bull; Phone: ${compPhone}
          </div>
        </div>
      `;
    }

    const matchedAccount = accounts.find(
      acc => acc.name === inv.accountName || acc.id === inv.accountName
    );
    const accountPhone = matchedAccount?.phone || compPhone;

    const getInvoiceTypeName = () => {
      switch (inv.invoiceType) {
        case 'SALES_CASH': return 'CASH SALES INVOICE';
        case 'SALES_CREDIT': return 'CREDIT SALES INVOICE';
        case 'PURCHASE_CASH': return 'CASH PURCHASE INVOICE';
        case 'PURCHASE_CREDIT': return 'CREDIT PURCHASE INVOICE';
        case 'SALES_MAUND': return 'MAUND SALES INVOICE (KG)';
        case 'PURCHASE_MAUND': return 'MAUND PURCHASE INVOICE (KG)';
        case 'SALES_RETURN': return 'SALES RETURN INVOICE';
        case 'PURCHASE_RETURN': return 'PURCHASE RETURN INVOICE';
        default: return 'INVOICE';
      }
    };

    const rowsHtml = inv.items
      .map(
        item => `
      <tr>
        <td style="font-weight:bold;text-transform:uppercase;">${item.productName}</td>
        <td style="text-align:center;">${item.packSize || '40kg'}</td>
        <td style="text-align:center;">${item.scheme || 'CASH SALE'}</td>
        <td style="text-align:center;font-family:monospace;">${item.lotNo || '-'}</td>
        <td style="text-align:center;font-weight:bold;font-family:monospace;">${item.quantity}</td>
        <td style="text-align:right;font-family:monospace;">${Number(item.rate).toFixed(2)}</td>
        <td style="text-align:right;font-family:monospace;">${(Number(item.discountAmount || 0)).toFixed(2)}</td>
        <td style="text-align:center;font-family:monospace;">${item.gstPercent || 0}%</td>
        <td style="text-align:right;font-family:monospace;">${(Number(item.gstAmount || 0)).toFixed(2)}</td>
        <td style="text-align:right;font-weight:bold;font-family:monospace;color:#064e3b;">${Number(item.amount).toLocaleString()}</td>
      </tr>
    `
      )
      .join('');

    const totalQty = inv.items.reduce((sum, i) => sum + Number(i.quantity || 0), 0);

    return `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 11px; color: #111827; background: #ffffff; width: 100%; min-height: 265mm; display: flex; flex-direction: column; justify-content: space-between; padding: 10mm; box-sizing: border-box;">
        <div>
        <div style="display:flex;align-items:center;justify-content:space-between;border-bottom:2.5px solid #064e3b;padding-bottom:10px;margin-bottom:12px;">
          <div style="display:flex;align-items:center;gap:12px;">
            <img src="${logoUrl}" style="width:54px;height:54px;object-fit:contain;" alt="Logo" onerror="this.style.display='none'" />
            <div>
              <h1 style="margin:0;font-size:19px;font-weight:900;color:#064e3b;text-transform:uppercase;letter-spacing:0.5px;">${compName}</h1>
              <div style="font-size:11px;color:#374151;margin-top:2px;">${compAddr} &bull; PH: ${compPhone}</div>
            </div>
          </div>
          <div style="text-align:center;border:2px solid #064e3b;background:#f0fdf4;padding:6px 14px;border-radius:6px;">
            <span style="font-weight:900;color:#064e3b;font-size:13px;text-transform:uppercase;letter-spacing:1px;">${getInvoiceTypeName()}</span>
          </div>
        </div>

        <div style="display:flex;justify-content:space-between;margin-bottom:12px;font-size:11.5px;line-height:1.5;">
          <div>
            <div><strong>${inv.invoiceType.includes('SALES') ? 'CUSTOMER' : 'SUPPLIER'}:</strong> <span style="font-weight:bold;color:#064e3b;text-transform:uppercase;">${inv.accountName}</span></div>
            <div><strong>Contact #:</strong> <span style="font-family:monospace;">${accountPhone}</span></div>
            ${matchedAccount?.description ? `<div><strong>Remarks:</strong> ${matchedAccount.description}</div>` : ''}
          </div>
          <div style="text-align:right;">
            <div><strong>INVOICE NO:</strong> <span style="font-family:monospace;font-weight:bold;color:#064e3b;">${inv.invoiceNo}</span></div>
            <div><strong>DATE:</strong> <span style="font-family:monospace;">${formatDate(inv.date)}</span></div>
            <div><strong>TERRITORY:</strong> <span style="text-transform:uppercase;">${inv.territory || 'SAHIWAL'}</span></div>
            <div><strong>SALES STAFF:</strong> <span style="text-transform:uppercase;">${inv.salesStaff || 'MARKET'}</span></div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th>Products</th>
              <th style="width:75px;text-align:center;">Pack Size</th>
              <th style="width:85px;text-align:center;">Scheme</th>
              <th style="width:75px;text-align:center;">Lot #</th>
              <th style="width:65px;text-align:center;">Quantity</th>
              <th style="width:80px;text-align:right;">Price</th>
              <th style="width:75px;text-align:right;">Discount</th>
              <th style="width:60px;text-align:center;">GST %</th>
              <th style="width:75px;text-align:right;">GST</th>
              <th style="width:95px;text-align:right;">Total (PKR)</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>

        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-top:14px;font-size:11px;">
          <div style="border:1px solid #d1d5db;background:#f9fafb;padding:8px 10px;border-radius:6px;">
            <div><strong>Payment Mode:</strong> ${inv.invoiceType.replace('_', ' ')}</div>
            <div><strong>Invoice Total:</strong> <span style="font-family:monospace;font-weight:bold;">PKR ${inv.netTotal.toLocaleString()}</span></div>
            <div style="border-top:1px solid #d1d5db;margin-top:4px;padding-top:4px;font-size:12px;font-weight:900;color:#064e3b;">
              Net Due: PKR ${inv.netTotal.toLocaleString()}
            </div>
          </div>
          <div style="border:1px solid #d1d5db;background:#f0fdf4;padding:8px 10px;border-radius:6px;text-align:center;display:flex;flex-direction:column;justify-content:center;">
            <div style="font-size:10px;font-weight:800;color:#047857;text-transform:uppercase;">TOTAL UNITS / BAGS</div>
            <div style="font-size:22px;font-weight:900;color:#064e3b;font-family:monospace;">${totalQty}</div>
          </div>
          <div style="border:1px solid #d1d5db;background:#f9fafb;padding:8px 10px;border-radius:6px;text-align:right;">
            <div>Gross Amount: <span style="font-family:monospace;">PKR ${inv.grossTotal.toLocaleString()}</span></div>
            <div>Discount: <span style="font-family:monospace;color:#b91c1c;">- PKR ${inv.discountTotal.toLocaleString()}</span></div>
            <div style="border-top:1px solid #d1d5db;margin-top:4px;padding-top:4px;font-size:12px;font-weight:900;color:#064e3b;">
              Net Total: PKR ${inv.netTotal.toLocaleString()}
            </div>
          </div>
        </div>

        <div style="margin-top:1in;margin-bottom:0.5in;padding:8px 10px;background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;font-size:10px;line-height:1.4;direction:rtl;text-align:right;">
          <div style="font-weight:bold;color:#064e3b;margin-bottom:3px;font-size:10.5px;">📑 اسٹاک کی وصولی اور چیکنگ (Stock Verification)</div>
          <div>• <strong>فوری چیکنگ:</strong> خریدار سامان وصول کرتے ہی اس کی تعداد اور حالت کو اچھی طرح چیک کرنے کا پابند ہے۔</div>
          <div>• <strong>شکایت کا وقت:</strong> اسٹاک میں کسی بھی قسم کی کمی، خرابی یا نقصان کی صورت میں 24 سے 48 گھنٹوں کے اندر کمپنی کو مطلع کرنا لازمی ہے۔ اس وقت کے بعد کوئی بھی شکایت قابلِ قبول نہیں ہوگی۔</div>
          <div>• <strong>دستخط کی اہمیت:</strong> سامان کی رسید (Delivery Challan/Invoice) پر خریدار یا اس کے نمائندے کے دستخط اس بات کا ثبوت ہیں کہ مال مکمل اور تسلی بخش حالت میں موصول ہو چکا ہے۔</div>
        </div>

        <div>
          <div style="margin-top:40px;padding-top:16px;border-top:1.5px solid #111827;display:grid;grid-template-columns:repeat(5, 1fr);gap:10px;font-size:10px;text-align:center;">
            <div>
              <div style="border-top:1.5px solid #111827;padding-top:5px;font-weight:bold;">Prepared By: ${inv.createdBy || 'Staff'}</div>
            </div>
            <div>
              <div style="border-top:1.5px solid #111827;padding-top:5px;font-weight:bold;">Store Keeper</div>
            </div>
            <div>
              <div style="border-top:1.5px solid #111827;padding-top:5px;font-weight:bold;">Received By</div>
            </div>
            <div>
              <div style="border-top:1.5px solid #111827;padding-top:5px;font-weight:bold;">Authorized Signatory</div>
            </div>
            <div>
              <div style="border-top:1.5px solid #111827;padding-top:5px;font-weight:bold;">Sign & Stamp</div>
            </div>
          </div>

          <div style="text-align:center;font-size:10px;color:#6b7280;margin-top:20px;border-top:1px dashed #d1d5db;padding-top:6px;">
            ${compName} &bull; ${compAddr} &bull; Phone: ${compPhone}
          </div>
        </div>
      </div>
    `;
  };

  const handlePrintInvoice = (inv: Invoice) => {
    const compName = companyProfile?.companyName || 'AUGUSTA SEED COMPANY';
    const htmlContent = buildInvoiceHtml(inv);
    printReportDirect({
      title: `${compName} - Invoice ${inv.invoiceNo}`,
      htmlContent,
      landscape: false
    });
  };

  const handleExportInvoicePdf = async (inv: Invoice) => {
    const compName = companyProfile?.companyName || 'AUGUSTA SEED COMPANY';
    const htmlContent = buildInvoiceHtml(inv);
    await downloadPdfFromReportHtml({
      htmlContent,
      filename: `${compName.replace(/\s+/g, '_')}_Invoice_${inv.invoiceNo}.pdf`,
      landscape: false
    });
  };

  const handleEdit = (inv: Invoice) => {
    setEditingInvoice(inv);
    setInvoiceNo(inv.invoiceNo);
    setDate(inv.date);
    setAccountName(inv.accountName);
    setSalesStaff(inv.salesStaff || '');
    setTerritory(inv.territory || '');
    setReason(inv.reason || '');
    setItems(
      inv.items.map(it => {
        const qty = Number(it.quantity || 0);
        const rate = Number(it.rate || 0);
        const gross = qty * rate;
        const disc = Number(it.discount || 0);
        const dType = it.discountType || 'PERCENT';
        let discAmt = it.discountAmount;
        if (discAmt === undefined) {
          if (dType === 'UNIT') discAmt = qty * disc;
          else if (dType === 'FIXED') discAmt = disc;
          else discAmt = (gross * disc) / 100;
        }
        return {
          ...it,
          discountType: dType,
          discountAmount: Math.round(Number(discAmt || 0) * 100) / 100
        };
      })
    );
    setRemarks(inv.remarks || '');
  };

  const handleCancelEdit = () => {
    setEditingInvoice(null);
    setInvoiceNo(`${activeTab.substring(0, 3)}-${Math.floor(1000 + Math.random() * 9000)}`);
    setDate(new Date().toISOString().split('T')[0]);
    setAccountName('');
    setSalesStaff('');
    setTerritory('');
    setReason('');
    setItems([createEmptyItem()]);
    setRemarks('');
  };

  const handleAddItem = () => {
    setItems([...items, createEmptyItem()]);
  };

  const handleRemoveItem = (index: number) => {
    if (items.length === 1) return;
    setItems(items.filter((_, idx) => idx !== index));
  };

  const handleItemChange = (index: number, field: keyof InvoiceItem, value: any) => {
    const updated = [...items];
    if (field === 'productId') {
      const prod = products.find(p => p.id === value);
      updated[index].productId = value;
      updated[index].productName = prod ? prod.productName : '';
      updated[index].unit = prod ? prod.unit : 'Bag';
      updated[index].packSize = prod ? prod.packSize : '40kg';
      updated[index].scheme = 'CASH SALE';
      updated[index].rate = activeTab.includes('SALES') ? prod?.saleRate || 0 : prod?.purchaseRate || 0;
    } else {
      (updated[index] as any)[field] = value;
    }

    // Recalculate amount
    const qty = Number(updated[index].quantity || 0);
    const rate = Number(updated[index].rate || 0);
    const rawDisc = Number(updated[index].discount || 0);
    const dType = updated[index].discountType || 'PERCENT';
    const unit = updated[index].unit || 'Bag';
    const isMaund = unit.toLowerCase().includes('maund');
    const gross = isMaund ? (qty / 40) * rate : qty * rate;

    let calcDisc = 0;
    if (dType === 'PERCENT' || (dType as string) === 'PERCENT_AMOUNT') {
      // Percentage-wise on amount: e.g. qty 2, rate 100, disc 10% -> 200 * (10/100) = 20, net 180
      calcDisc = (gross * rawDisc) / 100;
    } else if (dType === 'UNIT') {
      // Discount on qty (per unit): e.g. qty 2, rate 1000, disc 100 per unit -> 2 * 100 = 200, net 1800
      calcDisc = qty * rawDisc;
    } else if (dType === 'FIXED') {
      // Flat lump-sum discount on the line
      calcDisc = rawDisc;
    } else {
      calcDisc = (gross * rawDisc) / 100;
    }

    const roundedDisc = Math.max(0, Math.min(gross, Math.round(calcDisc * 100) / 100));
    updated[index].discountAmount = roundedDisc;

    const gstPct = Number(updated[index].gstPercent || 0);
    const baseAmount = gross - roundedDisc;
    const gstAmt = (baseAmount * gstPct) / 100;
    updated[index].gstAmount = Math.round(gstAmt * 100) / 100;
    updated[index].amount = Math.round((baseAmount + gstAmt) * 100) / 100;

    setItems(updated);
  };

  const grossTotal = items.reduce((sum, item) => {
    const q = Number(item.quantity || 0);
    const r = Number(item.rate || 0);
    const u = item.unit || 'Bag';
    const isM = u.toLowerCase().includes('maund');
    return sum + (isM ? (q / 40) * r : q * r);
  }, 0);
  const discountTotal = items.reduce((sum, item) => {
    const q = Number(item.quantity || 0);
    const r = Number(item.rate || 0);
    const u = item.unit || 'Bag';
    const isM = u.toLowerCase().includes('maund');
    const grossLine = isM ? (q / 40) * r : q * r;
    if (item.discountAmount !== undefined) return sum + Number(item.discountAmount || 0);
    const d = Number(item.discount || 0);
    const dt = item.discountType || 'PERCENT';
    const val = dt === 'UNIT' ? q * d : dt === 'FIXED' ? d : (grossLine * d) / 100;
    return sum + Math.max(0, Math.min(grossLine, val));
  }, 0);
  const netTotal = items.reduce((sum, item) => sum + Number(item.amount || 0), 0);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accountName) {
      alert('Please select customer or supplier account.');
      return;
    }

    const newInvoice: Invoice = {
      id: editingInvoice ? editingInvoice.id : `inv_${Date.now()}`,
      invoiceNo,
      invoiceType: activeTab,
      date,
      accountName,
      salesStaff,
      territory,
      reason,
      items,
      grossTotal,
      discountTotal,
      netTotal,
      remarks,
      createdBy: currentUser.fullName,
      createdAt: editingInvoice ? editingInvoice.createdAt : new Date().toISOString()
    };

    await db.saveInvoice(newInvoice);
    alert(editingInvoice ? 'Invoice updated successfully!' : 'Invoice saved & posted to MySQL successfully!');
    loadData();
  };

  const handleDelete = async (id: string) => {
    if (currentUser.role !== 'ADMIN') {
      alert('Normal users cannot delete saved invoices.');
      return;
    }
    if (confirm('Are you sure you want to delete this invoice?')) {
      await db.deleteInvoice(id);
      loadData();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">
            {activeTab === 'SALES_CASH' && 'Cash Sales Invoice'}
            {activeTab === 'SALES_CREDIT' && 'Credit Sales Invoice'}
            {activeTab === 'PURCHASE_CASH' && 'Cash Purchase Invoice'}
            {activeTab === 'PURCHASE_CREDIT' && 'Credit Purchase Invoice'}
            {activeTab === 'SALES_MAUND' && 'Maund Sales Invoice (Kg)'}
            {activeTab === 'PURCHASE_MAUND' && 'Maund Purchase Invoice (Kg)'}
            {activeTab === 'SALES_RETURN' && 'Sales Return Invoice'}
            {activeTab === 'PURCHASE_RETURN' && 'Purchase Return Invoice'}
          </h2>
          <p className="text-sm text-gray-500">Manage seed sales, purchase transactions, and inventory updates</p>
        </div>
        <div className="flex space-x-1 bg-white p-1 rounded-xl border border-gray-200 overflow-x-auto">
          <button
            onClick={() => setActiveTab('SALES_CREDIT')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'SALES_CREDIT' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Credit Sales
          </button>
          <button
            onClick={() => setActiveTab('SALES_CASH')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'SALES_CASH' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Cash Sales
          </button>
          <button
            onClick={() => setActiveTab('SALES_MAUND')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'SALES_MAUND' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Maund Sales
          </button>
          <button
            onClick={() => setActiveTab('PURCHASE_CREDIT')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'PURCHASE_CREDIT' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Purchase
          </button>
          <button
            onClick={() => setActiveTab('PURCHASE_MAUND')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'PURCHASE_MAUND' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Maund Purchase
          </button>
          <button
            onClick={() => setActiveTab('SALES_RETURN')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'SALES_RETURN' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Sales Return
          </button>
          <button
            onClick={() => setActiveTab('PURCHASE_RETURN')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
              activeTab === 'PURCHASE_RETURN' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Purchase Return
          </button>
        </div>
      </div>

      <form onSubmit={handleSave} className="bg-white rounded-xl border border-gray-200 shadow-xs p-6 space-y-6">
        {editingInvoice && (
          <div className="flex items-center justify-between bg-amber-50 border border-amber-200 p-3 rounded-lg text-amber-900 text-sm font-semibold">
            <span>Editing Invoice: {editingInvoice.invoiceNo}</span>
            <button type="button" onClick={handleCancelEdit} className="text-xs text-amber-800 underline font-semibold">
              Cancel Amendment
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Invoice No</label>
            <input
              type="text"
              required
              value={invoiceNo}
              onChange={e => setInvoiceNo(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden font-mono font-bold"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Invoice Date</label>
            <input
              type="date"
              required
              value={date}
              onChange={e => setDate(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">
              {activeTab.includes('SALES') ? 'Customer Account' : 'Supplier Account'}
            </label>
            <input
              type="text"
              placeholder="Search account..."
              value={accountSearch}
              onChange={e => setAccountSearch(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-1.5 text-xs mb-2 focus:border-emerald-600 focus:outline-hidden"
            />
            <select
              required
              value={accountName}
              onChange={e => setAccountName(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
            >
              <option value="">Select Account...</option>
              {accounts
                .filter(
                  acc =>
                    (acc.name || '').toLowerCase().includes(accountSearch.toLowerCase()) ||
                    (acc.code || '').toLowerCase().includes(accountSearch.toLowerCase())
                )
                .map(acc => (
                  <option key={acc.id} value={acc.name}>
                    {acc.code} - {acc.name}
                  </option>
                ))}
            </select>
          </div>
          {activeTab.includes('SALES') ? (
            <div>
              <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Sales Staff</label>
              <select
                value={salesStaff}
                onChange={e => setSalesStaff(e.target.value)}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
              >
                <option value="">Select Staff...</option>
                {staffList.map(s => (
                  <option key={s.id} value={s.staffName}>
                    {s.staffCode} - {s.staffName}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div>
              <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Territory</label>
              <select
                value={territory}
                onChange={e => setTerritory(e.target.value)}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
              >
                <option value="">Select Territory...</option>
                {territories.map(t => (
                  <option key={t.id} value={t.territoryName}>
                    {t.territoryCode} - {t.territoryName}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase tracking-wider text-gray-700">Product Line Items</h3>
            <button
              type="button"
              onClick={handleAddItem}
              className="flex items-center space-x-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Product Line</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-200 text-xs font-semibold uppercase text-gray-500 bg-gray-50">
                  <th className="py-3 px-3">Product / Seed Variety</th>
                  <th className="py-3 px-3 w-28">Pack Size</th>
                  <th className="py-3 px-3 w-24">Unit</th>
                  <th className="py-3 px-3 w-28">Scheme</th>
                  <th className="py-3 px-3 w-28">Lot No</th>
                  <th className="py-3 px-3 w-24">Qty (Kg if Maund)</th>
                  <th className="py-3 px-3 w-28 text-right">Rate</th>
                  <th className="py-3 px-3 min-w-[190px] text-right">Discount Mode & Value</th>
                  <th className="py-3 px-3 w-32 text-right">Amount (PKR)</th>
                  <th className="py-3 px-3 w-12 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-sm">
                {items.map((item, idx) => (
                  <tr key={idx} className="hover:bg-gray-50/50">
                    <td className="py-3 px-3">
                      <input
                        type="text"
                        placeholder="Search product..."
                        value={productSearches[idx] || ''}
                        onChange={e => setProductSearches({ ...productSearches, [idx]: e.target.value })}
                        className="w-full rounded-lg border border-gray-300 px-2 py-1 text-xs mb-1 focus:border-emerald-600 focus:outline-hidden"
                      />
                      <select
                        required
                        value={item.productId}
                        onChange={e => handleItemChange(idx, 'productId', e.target.value)}
                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white font-medium"
                      >
                        <option value="">Select Product...</option>
                        {products
                          .filter(p => {
                            const q = (productSearches[idx] || '').toLowerCase();
                            const pName = (p.productName || '').toLowerCase();
                            const pCode = (p.productCode || '').toLowerCase();
                            const pVariety = (p.variety || '').toLowerCase();
                            return pName.includes(q) || pCode.includes(q) || pVariety.includes(q);
                          })
                          .map(p => (
                            <option key={p.id} value={p.id}>
                              {p.productCode} - {p.productName} ({p.packSize})
                            </option>
                          ))}
                      </select>
                    </td>
                    <td className="py-3 px-3">
                      <input
                        type="text"
                        value={item.packSize || ''}
                        onChange={e => handleItemChange(idx, 'packSize', e.target.value)}
                        className="w-full rounded-lg border border-gray-300 px-2 py-2 text-sm"
                      />
                    </td>
                    <td className="py-3 px-3">
                      <select
                        value={item.unit || 'Bag'}
                        onChange={e => handleItemChange(idx, 'unit', e.target.value)}
                        className="w-full rounded-lg border border-gray-300 px-2 py-2 text-sm bg-white font-medium"
                      >
                        <option value="Bag">Bag</option>
                        <option value="Maund">Maund (Kg)</option>
                        <option value="kg">kg</option>
                        <option value="Packet">Packet</option>
                      </select>
                    </td>
                    <td className="py-3 px-3">
                      <input
                        type="text"
                        value={item.scheme || ''}
                        onChange={e => handleItemChange(idx, 'scheme', e.target.value)}
                        className="w-full rounded-lg border border-gray-300 px-2 py-2 text-sm"
                      />
                    </td>
                    <td className="py-3 px-3">
                      <input
                        type="text"
                        value={item.lotNo || ''}
                        onChange={e => handleItemChange(idx, 'lotNo', e.target.value)}
                        className="w-full rounded-lg border border-gray-300 px-2 py-2 text-sm font-mono"
                      />
                    </td>
                    <td className="py-3 px-3">
                      <input
                        type="number"
                        min="1"
                        required
                        value={item.quantity}
                        onChange={e => handleItemChange(idx, 'quantity', Number(e.target.value))}
                        className="w-full rounded-lg border border-gray-300 px-2 py-2 text-sm font-semibold"
                      />
                    </td>
                    <td className="py-3 px-3 text-right">
                      <input
                        type="number"
                        step="0.01"
                        required
                        value={item.rate}
                        onChange={e => handleItemChange(idx, 'rate', Number(e.target.value))}
                        className="w-full text-right rounded-lg border border-gray-300 px-2 py-2 text-sm font-semibold"
                      />
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="space-y-1.5">
                        {/* Discount Mode Selector */}
                        <div className="flex rounded-md shadow-2xs border border-gray-300 overflow-hidden text-[10px] font-bold">
                          <button
                            type="button"
                            onClick={() => handleItemChange(idx, 'discountType', 'PERCENT')}
                            className={`flex-1 py-1 px-1.5 transition-colors ${
                              item.discountType === 'PERCENT' || !item.discountType || (item.discountType as string) === 'PERCENT_AMOUNT'
                                ? 'bg-emerald-700 text-white font-black'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                            }`}
                            title="Percentage on total amount: % of (Qty × Rate)"
                          >
                            % Amt
                          </button>
                          <button
                            type="button"
                            onClick={() => handleItemChange(idx, 'discountType', 'UNIT')}
                            className={`flex-1 py-1 px-1.5 transition-colors border-l border-gray-300 ${
                              item.discountType === 'UNIT'
                                ? 'bg-emerald-700 text-white font-black'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                            }`}
                            title="Discount per Unit / Qty: Qty × Rs/unit"
                          >
                            /Unit (Qty)
                          </button>
                          <button
                            type="button"
                            onClick={() => handleItemChange(idx, 'discountType', 'FIXED')}
                            className={`flex-1 py-1 px-1 transition-colors border-l border-gray-300 ${
                              item.discountType === 'FIXED'
                                ? 'bg-emerald-700 text-white font-black'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                            }`}
                            title="Flat fixed amount off this line"
                          >
                            Flat Rs
                          </button>
                        </div>
                        {/* Discount Value Input */}
                        <div className="relative">
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            value={item.discount}
                            onChange={e => handleItemChange(idx, 'discount', Number(e.target.value))}
                            placeholder={item.discountType === 'UNIT' ? 'Rs / unit' : item.discountType === 'FIXED' ? 'Flat Rs' : '% discount'}
                            className="w-full text-right rounded-lg border border-gray-300 px-2 py-1.5 text-sm font-semibold focus:border-emerald-600 focus:outline-hidden"
                          />
                          <span className="absolute left-2 top-1.5 text-[11px] text-gray-400 font-bold pointer-events-none uppercase">
                            {item.discountType === 'UNIT' ? 'Rs/unit' : item.discountType === 'FIXED' ? 'Flat' : '%'}
                          </span>
                        </div>
                        {/* Calculation Preview */}
                        {item.discount > 0 && (
                          <div className="text-[11px] text-right font-semibold text-emerald-800">
                            -PKR {(item.discountAmount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            <span className="text-gray-500 font-normal ml-1">
                              {item.discountType === 'UNIT'
                                ? `(@${item.discount}/unit)`
                                : item.discountType === 'FIXED'
                                ? '(flat)'
                                : `(${item.discount}%)`}
                            </span>
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <div className="font-bold text-gray-900 font-mono text-sm">{item.amount.toLocaleString()}</div>
                      {item.discount > 0 && (
                        <div className="text-[10px] text-gray-400 font-mono">
                          Gross: {(item.quantity * item.rate).toLocaleString()}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(idx)}
                        className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between bg-gray-50 p-4 rounded-xl border border-gray-200 flex-wrap gap-4">
            <div className="flex space-x-6 text-sm">
              <p>
                Gross Total: <span className="font-bold text-gray-800">PKR {grossTotal.toLocaleString()}</span>
              </p>
              <p>
                Discount: <span className="font-bold text-gray-800">PKR {discountTotal.toLocaleString()}</span>
              </p>
              <p className="text-base">
                Net Total: <span className="font-black text-emerald-800">PKR {netTotal.toLocaleString()}</span>
              </p>
            </div>
            <button
              type="submit"
              className={`flex items-center space-x-2 ${
                editingInvoice ? 'bg-amber-600 hover:bg-amber-700' : 'bg-emerald-700 hover:bg-emerald-800'
              } text-white px-6 py-2.5 rounded-lg text-sm font-semibold shadow-sm transition-colors`}
            >
              <Save className="w-4 h-4" />
              <span>{editingInvoice ? 'Update Invoice' : 'Save & Post Invoice'}</span>
            </button>
          </div>
        </div>
      </form>

      {/* Date-Wise Search & Filter Panel */}
      {(() => {
        const getTabLabel = (type: InvoiceType) => {
          switch (type) {
            case 'SALES_CREDIT': return 'Credit Sales';
            case 'SALES_CASH': return 'Cash Sales';
            case 'PURCHASE_CREDIT': return 'Credit Purchase';
            case 'PURCHASE_CASH': return 'Cash Purchase';
            case 'SALES_RETURN': return 'Sales Return';
            case 'PURCHASE_RETURN': return 'Purchase Return';
            default: return 'Invoices';
          }
        };

        const setQuickDate = (type: 'today' | 'yesterday' | '7days' | 'thisMonth' | 'all') => {
          const now = new Date();
          const todayStr = now.toISOString().split('T')[0];

          if (type === 'today') {
            setFilterStartDate(todayStr);
            setFilterEndDate(todayStr);
          } else if (type === 'yesterday') {
            const yest = new Date(now);
            yest.setDate(yest.getDate() - 1);
            const yestStr = yest.toISOString().split('T')[0];
            setFilterStartDate(yestStr);
            setFilterEndDate(yestStr);
          } else if (type === '7days') {
            const past = new Date(now);
            past.setDate(past.getDate() - 6);
            setFilterStartDate(past.toISOString().split('T')[0]);
            setFilterEndDate(todayStr);
          } else if (type === 'thisMonth') {
            const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
            setFilterStartDate(firstDay);
            setFilterEndDate(todayStr);
          } else if (type === 'all') {
            setFilterStartDate('');
            setFilterEndDate('');
            setSearchKeyword('');
          }
        };

        const filteredInvoices = invoices.filter(inv => {
          const invDate = inv.date ? inv.date.split('T')[0] : '';
          if (filterStartDate && invDate < filterStartDate) return false;
          if (filterEndDate && invDate > filterEndDate) return false;
          if (searchKeyword.trim()) {
            const q = searchKeyword.toLowerCase().trim();
            const matchNo = inv.invoiceNo.toLowerCase().includes(q);
            const matchAcc = (inv.accountName || '').toLowerCase().includes(q);
            const matchStaff = (inv.salesStaff || '').toLowerCase().includes(q);
            const matchTerr = (inv.territory || '').toLowerCase().includes(q);
            const matchRemarks = (inv.remarks || '').toLowerCase().includes(q);
            const matchItems = inv.items?.some(it =>
              (it.productName || '').toLowerCase().includes(q) ||
              (it.lotNo || '').toLowerCase().includes(q) ||
              (it.scheme || '').toLowerCase().includes(q)
            );
            if (!matchNo && !matchAcc && !matchStaff && !matchTerr && !matchRemarks && !matchItems) {
              return false;
            }
          }
          return true;
        });

        const filteredNetTotal = filteredInvoices.reduce((sum, inv) => sum + Number(inv.netTotal || 0), 0);
        const filteredGrossTotal = filteredInvoices.reduce((sum, inv) => sum + Number(inv.grossTotal || 0), 0);
        const filteredDiscountTotal = filteredInvoices.reduce((sum, inv) => sum + Number(inv.discountTotal || 0), 0);
        const isInvoiceFilterActive = Boolean(filterStartDate || filterEndDate || searchKeyword);

        return (
          <>
            {/* Filter Controls Card */}
            <div className="bg-white rounded-xl border border-gray-200 shadow-xs p-5 space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-gray-100 pb-3">
                <div>
                  <h3 className="text-base font-bold text-gray-800 flex items-center space-x-2">
                    <Calendar className="w-5 h-5 text-emerald-700" />
                    <span>Search & Filter {getTabLabel(activeTab)} Invoices</span>
                  </h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    Filter invoices date-wise, or search by Invoice #, Customer / Supplier, Territory, or Product
                  </p>
                </div>

                {/* Quick Date Presets */}
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  <span className="text-gray-400 font-semibold text-[11px] uppercase mr-1">Quick:</span>
                  <button
                    type="button"
                    onClick={() => setQuickDate('today')}
                    className="px-2.5 py-1 rounded-md bg-gray-100 hover:bg-emerald-50 hover:text-emerald-800 text-gray-700 font-medium transition-colors border border-gray-200"
                  >
                    Today
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickDate('yesterday')}
                    className="px-2.5 py-1 rounded-md bg-gray-100 hover:bg-emerald-50 hover:text-emerald-800 text-gray-700 font-medium transition-colors border border-gray-200"
                  >
                    Yesterday
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickDate('7days')}
                    className="px-2.5 py-1 rounded-md bg-gray-100 hover:bg-emerald-50 hover:text-emerald-800 text-gray-700 font-medium transition-colors border border-gray-200"
                  >
                    Last 7 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickDate('thisMonth')}
                    className="px-2.5 py-1 rounded-md bg-gray-100 hover:bg-emerald-50 hover:text-emerald-800 text-gray-700 font-medium transition-colors border border-gray-200"
                  >
                    This Month
                  </button>
                  {isInvoiceFilterActive && (
                    <button
                      type="button"
                      onClick={() => setQuickDate('all')}
                      className="flex items-center space-x-1 px-2.5 py-1 rounded-md bg-red-50 hover:bg-red-100 text-red-700 font-semibold transition-colors border border-red-200"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Reset</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Date Inputs & Search Bar Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 items-end">
                <div>
                  <label className="block text-xs font-semibold uppercase text-gray-600 mb-1 flex items-center space-x-1">
                    <Calendar className="w-3.5 h-3.5 text-gray-400" />
                    <span>From Date</span>
                  </label>
                  <input
                    type="date"
                    value={filterStartDate}
                    onChange={e => setFilterStartDate(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-gray-600 mb-1 flex items-center space-x-1">
                    <Calendar className="w-3.5 h-3.5 text-gray-400" />
                    <span>To Date</span>
                  </label>
                  <input
                    type="date"
                    value={filterEndDate}
                    onChange={e => setFilterEndDate(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold uppercase text-gray-600 mb-1 flex items-center space-x-1">
                    <Search className="w-3.5 h-3.5 text-gray-400" />
                    <span>Search Invoice # / Account / Product / Staff</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search by invoice #, customer/supplier, staff, variety..."
                      value={searchKeyword}
                      onChange={e => setSearchKeyword(e.target.value)}
                      className="w-full rounded-lg border border-gray-300 pl-9 pr-8 py-2 text-sm focus:border-emerald-600 focus:outline-hidden"
                    />
                    <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                    {searchKeyword && (
                      <button
                        type="button"
                        onClick={() => setSearchKeyword('')}
                        className="absolute right-2.5 top-2.5 text-gray-400 hover:text-gray-600"
                        title="Clear search keyword"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Summary Stats Row */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-xs">
                <div className="flex flex-wrap items-center gap-2 text-gray-600">
                  <span>
                    Showing <strong className="text-gray-900 font-bold">{filteredInvoices.length}</strong> of{' '}
                    <strong className="text-gray-900 font-bold">{invoices.length}</strong> invoices
                  </span>
                  {isInvoiceFilterActive && (
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800">
                      Active: {filterStartDate ? `From ${filterStartDate}` : ''} {filterEndDate ? `To ${filterEndDate}` : ''} {searchKeyword ? `"${searchKeyword}"` : ''}
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-4 text-sm font-semibold">
                  <span className="text-gray-600">
                    Gross: <strong className="font-mono text-gray-900">PKR {filteredGrossTotal.toLocaleString()}</strong>
                  </span>
                  <span className="text-gray-600">
                    Discount: <strong className="font-mono text-gray-900">PKR {filteredDiscountTotal.toLocaleString()}</strong>
                  </span>
                  <span className="text-emerald-800">
                    Net Total: <strong className="font-mono font-bold text-emerald-900">PKR {filteredNetTotal.toLocaleString()}</strong>
                  </span>
                </div>
              </div>
            </div>

            {/* Invoices List Table */}
            <div className="bg-white rounded-xl border border-gray-200 shadow-xs p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-800">
                  Recent {getTabLabel(activeTab)} Invoices ({filteredInvoices.length})
                </h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-gray-200 text-xs font-semibold uppercase text-gray-500 bg-gray-50">
                      <th className="py-3 px-4">Invoice No</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Account / Customer</th>
                      <th className="py-3 px-4">Sales Staff</th>
                      <th className="py-3 px-4 text-right">Net Amount (PKR)</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 text-sm">
                    {filteredInvoices.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="text-center py-10 text-gray-400">
                          {isInvoiceFilterActive ? (
                            <div className="space-y-2">
                              <p className="font-medium text-gray-600">No invoices found matching your date or search filters.</p>
                              <button
                                type="button"
                                onClick={() => setQuickDate('all')}
                                className="inline-flex items-center space-x-1 text-xs text-emerald-700 hover:text-emerald-800 underline font-semibold"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                <span>Clear all filters</span>
                              </button>
                            </div>
                          ) : (
                            'No invoices recorded for this module.'
                          )}
                        </td>
                      </tr>
                    ) : (
                      filteredInvoices.map(inv => (
                        <tr key={inv.id} className="hover:bg-gray-50/50">
                          <td className="py-3 px-4 font-mono font-bold text-emerald-800">{inv.invoiceNo}</td>
                          <td className="py-3 px-4 text-gray-600 font-mono text-xs">{formatDate(inv.date)}</td>
                          <td className="py-3 px-4 font-semibold text-gray-800">{inv.accountName}</td>
                          <td className="py-3 px-4 text-gray-600">{inv.salesStaff || 'N/A'}</td>
                          <td className="py-3 px-4 text-right font-black text-emerald-700">{inv.netTotal.toLocaleString()}</td>
                          <td className="py-3 px-4 text-right space-x-2">
                            <button
                              onClick={() => setSelectedPrintInvoice(inv)}
                              className="p-1.5 text-gray-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg"
                              title="Print Invoice"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleEdit(inv)}
                              className="p-1.5 text-gray-500 hover:text-amber-700 hover:bg-amber-50 rounded-lg"
                              title="Edit / Amend"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            {currentUser.role === 'ADMIN' && (
                              <button
                                onClick={() => handleDelete(inv.id)}
                                className="p-1.5 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                                title="Delete"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        );
      })()}

      {/* PRINT PREVIEW MODAL */}
      {selectedPrintInvoice && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
            <div className="flex items-center justify-between px-6 py-4 bg-gray-900 text-white print:hidden">
              <h3 className="font-bold text-lg flex items-center space-x-2">
                <Printer className="w-5 h-5 text-emerald-400" />
                <span>{companyProfile?.companyName || 'AUGUSTA SEED COMPANY'} - Invoice Print Preview</span>
              </h3>
              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={() => handlePrintInvoice(selectedPrintInvoice)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-semibold flex items-center space-x-1.5 cursor-pointer shadow-sm transition-colors"
                  title="Print directly to Default Printer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Invoice</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleExportInvoicePdf(selectedPrintInvoice)}
                  className="bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm font-semibold flex items-center space-x-1.5 cursor-pointer border border-gray-700 transition-colors"
                  title="Download PDF matching print layout"
                >
                  <Download className="w-4 h-4" />
                  <span>Export PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedPrintInvoice(null)}
                  className="p-2 text-gray-400 hover:text-white rounded-lg hover:bg-gray-800 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-8 overflow-y-auto bg-white text-black font-sans space-y-6 print:p-0">
              {/* Header */}
              <div className="flex items-start justify-between border-b-2 border-emerald-800 pb-4">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 rounded-xl bg-white border border-gray-300 flex items-center justify-center overflow-hidden p-1 shadow-xs">
                    <img src={companyProfile?.logoUrl || '/logoittehad.png'} alt="Logo" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-black text-emerald-900 tracking-wider uppercase">
                      {companyProfile?.companyName || 'AUGUSTA SEED COMPANY'}
                    </h1>
                    <p className="text-xs font-bold text-gray-700 mt-0.5">
                      HEAD OFFICE: {companyProfile?.headOfficeAddress || 'UNITED FARM ROAD, GULSHAN-E-ALI BY PASS, SAHIWAL'} PH.{companyProfile?.phone || companyProfile?.mobile || '03023576036'}
                    </p>
                  </div>
                </div>
                <div className="text-center border-2 border-emerald-800 px-6 py-1.5 rounded bg-emerald-50">
                  <span className="text-sm font-black text-emerald-900 uppercase tracking-widest">
                    {selectedPrintInvoice.invoiceType === 'SALES_CASH' && 'CASH SALES INVOICE'}
                    {selectedPrintInvoice.invoiceType === 'SALES_CREDIT' && 'SALES INVOICE'}
                    {selectedPrintInvoice.invoiceType === 'PURCHASE_CASH' && 'CASH PURCHASE INVOICE'}
                    {selectedPrintInvoice.invoiceType === 'PURCHASE_CREDIT' && 'PURCHASE INVOICE'}
                    {selectedPrintInvoice.invoiceType === 'SALES_RETURN' && 'SALES RETURN INVOICE'}
                    {selectedPrintInvoice.invoiceType === 'PURCHASE_RETURN' && 'PURCHASE RETURN INVOICE'}
                  </span>
                </div>
              </div>

              {/* Meta Grid */}
              {(() => {
                const matchedAccount = accounts.find(
                  acc => acc.name === selectedPrintInvoice.accountName || acc.id === selectedPrintInvoice.accountName
                );
                const accountPhone = matchedAccount?.phone || '03216533233';
                const accountDescription = matchedAccount?.description || '';

                return (
                  <div className="grid grid-cols-2 gap-8 text-sm">
                    <div className="space-y-1">
                      <p className="font-bold text-gray-900">
                        {selectedPrintInvoice.invoiceType.includes('SALES') ? 'CUSTOMER' : 'SUPPLIER'} :{' '}
                        <span className="font-semibold uppercase">{selectedPrintInvoice.accountName}</span>
                      </p>
                      <p className="text-gray-700 font-medium">
                        Contact #: <span className="font-mono">{accountPhone}</span>
                      </p>
                      {accountDescription && (
                        <p className="text-gray-600 text-xs italic mt-0.5">Remarks: {accountDescription}</p>
                      )}
                    </div>
                    <div className="space-y-1 text-right">
                      <p className="font-bold">
                        INVOICE NO. : <span className="font-mono">{selectedPrintInvoice.invoiceNo}</span>
                      </p>
                      <p className="font-bold">
                        Date : <span className="font-mono">{selectedPrintInvoice.date}</span>
                      </p>
                      <p className="font-bold">
                        TERRITORY :{' '}
                        <span className="font-normal uppercase">{selectedPrintInvoice.territory || 'ARIFWALA'}</span>
                      </p>
                      <p className="font-bold">
                        SALE STAFF :{' '}
                        <span className="font-normal uppercase">{selectedPrintInvoice.salesStaff || 'MARKET'}</span>
                      </p>
                    </div>
                  </div>
                );
              })()}

              {/* Items Table */}
              <table className="w-full border-collapse border border-gray-400 text-xs">
                <thead>
                  <tr className="bg-emerald-900 text-white font-bold uppercase text-center">
                    <th className="border border-emerald-900 py-2 px-2 text-left">Products</th>
                    <th className="border border-emerald-900 py-2 px-2">Pack size</th>
                    <th className="border border-emerald-900 py-2 px-2">Scheme</th>
                    <th className="border border-emerald-900 py-2 px-2">Lot No</th>
                    <th className="border border-emerald-900 py-2 px-2">Quantity</th>
                    <th className="border border-emerald-900 py-2 px-2 text-right">Price</th>
                    <th className="border border-emerald-900 py-2 px-2 text-right">Dis.</th>
                    <th className="border border-emerald-900 py-2 px-2 text-center">GST%</th>
                    <th className="border border-emerald-900 py-2 px-2 text-right">GST</th>
                    <th className="border border-emerald-900 py-2 px-2 text-right">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-300">
                  {selectedPrintInvoice.items.map((item, idx) => (
                    <tr key={idx} className="text-gray-900 font-medium">
                      <td className="border border-gray-300 py-2 px-2 uppercase font-bold">{item.productName}</td>
                      <td className="border border-gray-300 py-2 px-2 text-center">{item.packSize || '40kg'}</td>
                      <td className="border border-gray-300 py-2 px-2 text-center">{item.scheme || 'CASH SALE'}</td>
                      <td className="border border-gray-300 py-2 px-2 text-center font-mono">{item.lotNo || ''}</td>
                      <td className="border border-gray-300 py-2 px-2 text-center font-bold">{item.quantity}</td>
                      <td className="border border-gray-300 py-2 px-2 text-right font-mono">{item.rate.toFixed(2)}</td>
                      <td className="border border-gray-300 py-2 px-2 text-right font-mono">
                        {item.discount > 0 ? (
                          <div>
                            <div>
                              {(item.discountAmount !== undefined
                                ? item.discountAmount
                                : item.discountType === 'UNIT'
                                ? item.quantity * item.discount
                                : item.discountType === 'FIXED'
                                ? item.discount
                                : (item.quantity * item.rate * item.discount) / 100
                              ).toFixed(2)}
                            </div>
                            <div className="text-[10px] text-gray-500 font-sans">
                              {item.discountType === 'UNIT'
                                ? `@${item.discount}/unit`
                                : item.discountType === 'FIXED'
                                ? 'flat'
                                : `${item.discount}%`}
                            </div>
                          </div>
                        ) : (
                          '0.00'
                        )}
                      </td>
                      <td className="border border-gray-300 py-2 px-2 text-center font-mono">{item.gstPercent || 0}</td>
                      <td className="border border-gray-300 py-2 px-2 text-right font-mono">
                        {(item.gstAmount || 0).toFixed(2)}
                      </td>
                      <td className="border border-gray-300 py-2 px-2 text-right font-bold font-mono">
                        {item.amount.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Summary Section */}
              <div className="grid grid-cols-3 gap-4 pt-2 text-xs">
                <div className="border border-gray-400 p-3 space-y-1 bg-gray-50 rounded-lg">
                  <div className="flex justify-between font-semibold">
                    <span>Payment Mode :</span>
                    <span className="font-mono">{selectedPrintInvoice.invoiceType.replace('_', ' ')}</span>
                  </div>
                  <div className="flex justify-between font-semibold">
                    <span>Invoice Total:</span>
                    <span className="font-mono">{selectedPrintInvoice.netTotal.toLocaleString()}</span>
                  </div>
                  <hr className="border-gray-300 my-1" />
                  <div className="flex justify-between font-bold text-gray-900 text-sm">
                    <span>Net Due :</span>
                    <span className="font-mono">{selectedPrintInvoice.netTotal.toLocaleString()} PKR</span>
                  </div>
                </div>

                <div className="flex flex-col items-center justify-center border border-gray-400 p-3 bg-gray-50 rounded-lg">
                  <span className="font-bold text-gray-700 uppercase">Total Units / Bags:</span>
                  <span className="text-2xl font-black text-emerald-900 mt-1">
                    {selectedPrintInvoice.items.reduce((sum, i) => sum + Number(i.quantity || 0), 0)}
                  </span>
                </div>

                <div className="border border-gray-400 p-3 space-y-1 bg-gray-50 rounded-lg">
                  <div className="flex justify-between font-semibold">
                    <span>Gross Amount:</span>
                    <span className="font-mono">{selectedPrintInvoice.grossTotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between font-semibold">
                    <span>Discount:</span>
                    <span className="font-mono">{selectedPrintInvoice.discountTotal.toLocaleString()}</span>
                  </div>
                  <hr className="border-gray-300 my-1" />
                  <div className="flex justify-between font-bold text-gray-900 text-sm border-t border-black pt-1">
                    <span>Net Total :</span>
                    <span className="font-mono font-black text-emerald-900">
                      {selectedPrintInvoice.netTotal.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Signatures */}
              <div className="pt-6 space-y-4 text-xs font-semibold">
                <div className="grid grid-cols-3 gap-6 border-t-2 border-emerald-950 pt-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-gray-700">USER NAME:</span>
                    <span className="font-mono uppercase">{selectedPrintInvoice.createdBy}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-gray-700">STORE KEEPER:</span>
                    <div className="border-b border-black flex-1"></div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-gray-700">AUTHORIZED SIGN:</span>
                    <div className="border-b border-black flex-1"></div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-12 pt-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-gray-700">RECEIVED BY:</span>
                    <div className="border-b border-black flex-1"></div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-gray-700">SIGN & STAMP:</span>
                    <div className="border-b border-black flex-1"></div>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="text-center pt-6 border-t border-gray-300 text-[11px] font-semibold text-gray-500">
                {companyProfile?.companyName || 'AUGUSTA SEED COMPANY'} • {companyProfile?.headOfficeAddress || 'UNITED FARM ROAD, GULSHAN-E-ALI BY PASS, SAHIWAL'} • Phone: {companyProfile?.phone || companyProfile?.mobile || '03023576036'}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
