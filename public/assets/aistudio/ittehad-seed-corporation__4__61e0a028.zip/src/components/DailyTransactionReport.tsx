import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { Invoice, Voucher, CompanyProfileData, Account } from '../types';
import { Printer, Download, Search } from 'lucide-react';
import { formatDate } from '../utils/dateUtils';
import * as XLSX from 'xlsx';
import {
  printReportDirect,
  downloadPdfFromReportHtml,
  buildStandardReportHeaderHtml,
  buildStandardReportFooterHtml
} from '../utils/reportPrinter';

export const DailyTransactionReportComponent: React.FC = () => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [companyProfile, setCompanyProfile] = useState<CompanyProfileData | null>(null);
  const today = new Date().toISOString().split('T')[0];
  const [dateFrom, setDateFrom] = useState(today);
  const [dateTo, setDateTo] = useState(today);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const invs = await db.getInvoices();
    const vocs = await db.getVouchers();
    const accs = await db.getAccounts();
    const profile = await db.getCompanyProfile();
    setInvoices(invs);
    setVouchers(vocs);
    setAccounts(accs);
    setCompanyProfile(profile);
  };

  const getAccountCode = (name: string) => {
    const acc = accounts.find(a => a.name.toLowerCase() === name.toLowerCase());
    return acc ? acc.code : '1000';
  };

  const filteredInvoices = invoices.filter(i => i.date >= dateFrom && i.date <= dateTo);
  const filteredVouchers = vouchers.filter(v => v.date >= dateFrom && v.date <= dateTo);

  const salesReturns = filteredInvoices.filter(i => i.invoiceType === 'SALES_RETURN');
  const purchaseReturns = filteredInvoices.filter(i => i.invoiceType === 'PURCHASE_RETURN');
  const payments = filteredVouchers.filter(v => v.voucherType === 'CASH_PAYMENT');
  const receipts = filteredVouchers.filter(v => v.voucherType === 'CASH_RECEIPT');
  const journals = filteredVouchers.filter(v => v.voucherType === 'JOURNAL');
  const purchases = filteredInvoices.filter(i => i.invoiceType === 'PURCHASE_CASH' || i.invoiceType === 'PURCHASE_CREDIT' || i.invoiceType === 'PURCHASE_MAUND');
  const sales = filteredInvoices.filter(i => i.invoiceType === 'SALES_CASH' || i.invoiceType === 'SALES_CREDIT' || i.invoiceType === 'SALES_MAUND');

  const getCashBalanceUpTo = (targetDate: string, isEnd: boolean = true) => {
    const cashAcc = accounts.find(a => a.code === 'ACC-10000' || a.name.toLowerCase().includes('cash in hand'));
    if (!cashAcc) return 0;
    let bal = cashAcc.openingBalanceType === 'Dr' ? Number(cashAcc.openingBalance || 0) : -Number(cashAcc.openingBalance || 0);
    const dateCondition = (d: string) => isEnd ? d <= targetDate : d < targetDate;

    vouchers.forEach(v => {
      const vDate = v.date ? v.date.split('T')[0] : '';
      if (vDate && dateCondition(vDate)) {
        v.lines?.forEach(l => {
          if (
            l.accountId === cashAcc.id ||
            l.accountId === cashAcc.code ||
            l.accountName === cashAcc.name ||
            l.accountName.toLowerCase().includes('cash in hand')
          ) {
            bal += Number(l.debit || 0) - Number(l.credit || 0);
          }
        });
      }
    });

    invoices.forEach(inv => {
      const invDate = inv.date ? inv.date.split('T')[0] : '';
      if (invDate && dateCondition(invDate)) {
        if (
          inv.accountName === cashAcc.name ||
          inv.accountName === cashAcc.id ||
          inv.accountName.toLowerCase() === cashAcc.name.toLowerCase() ||
          inv.accountName === cashAcc.code
        ) {
          let debit = 0;
          let credit = 0;
          if (inv.invoiceType === 'SALES_CASH' || inv.invoiceType === 'SALES_CREDIT' || inv.invoiceType === 'PURCHASE_RETURN') {
            debit = Number(inv.netTotal || 0);
          } else if (inv.invoiceType === 'SALES_RETURN' || inv.invoiceType === 'PURCHASE_CASH' || inv.invoiceType === 'PURCHASE_CREDIT') {
            credit = Number(inv.netTotal || 0);
          }
          bal += debit - credit;
        } else {
          if (inv.invoiceType === 'SALES_CASH') {
            bal += Number(inv.netTotal || 0);
          } else if (inv.invoiceType === 'PURCHASE_CASH') {
            bal -= Number(inv.netTotal || 0);
          }
        }
      }
    });

    return bal;
  };

  const cashBalFrom = getCashBalanceUpTo(dateFrom, false);
  const cashBalTo = getCashBalanceUpTo(dateTo, true);

  const totalCashSales = sales.filter(i => i.invoiceType === 'SALES_CASH').reduce((sum, i) => sum + i.netTotal, 0);
  const totalCreditSales = sales.filter(i => i.invoiceType === 'SALES_CREDIT').reduce((sum, i) => sum + i.netTotal, 0);
  const totalExps = payments.reduce((sum, v) => sum + v.totalAmount, 0);
  const totalPurchases = purchases.reduce((sum, i) => sum + i.netTotal, 0);
  const totalSalesBills = sales.length;
  const todayProfit = totalCashSales + totalCreditSales - totalPurchases - totalExps;

  const buildDailyReportHtml = (): string => {
    const compName = companyProfile?.companyName || 'AUGUSTA SEED COMPANY';
    const compAddr = companyProfile?.headOfficeAddress || 'UNITED FARM ROAD, GULSHAN-E-ALI BY PASS, SAHIWAL';
    const compPhone = companyProfile?.phone || companyProfile?.mobile || '03023576036';
    const logoUrl = companyProfile?.logoUrl || '/logoittehad.png';

    const headerHtml = buildStandardReportHeaderHtml({
      companyName: compName,
      headOfficeAddress: compAddr,
      phone: compPhone,
      logoUrl: logoUrl,
      reportTitle: 'DAILY TRANSACTION REPORT',
      periodText: `${formatDate(dateFrom)} to ${formatDate(dateTo)}`,
      metaLines: [
        `<strong>Today Expenses:</strong> PKR ${totalExps.toLocaleString()}`,
        `<strong>Today Profit:</strong> PKR ${todayProfit.toLocaleString()}`,
        `<strong>Cash Sales:</strong> PKR ${totalCashSales.toLocaleString()}`,
        `<strong>Credit Sales:</strong> PKR ${totalCreditSales.toLocaleString()}`,
        `<strong>Cash in Hand (${formatDate(dateFrom)}):</strong> PKR ${cashBalFrom.toLocaleString()}`,
        `<strong>Cash in Hand (${formatDate(dateTo)}):</strong> PKR ${cashBalTo.toLocaleString()}`
      ]
    });

    let sectionsHtml = '';

    const renderSection = (title: string, rows: any[], subtotalLabel: string, debitSub: string, creditSub: string, totalSub: string) => {
      if (rows.length === 0) return '';
      return `
        <tr style="background:#f0fdf4;border-top:2px solid #064e3b;">
          <td colspan="6" style="padding:6px 8px;font-weight:900;color:#064e3b;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;">
            ${title}
          </td>
        </tr>
        ${rows
          .map(
            r => `
          <tr>
            <td style="font-family:monospace;font-size:10px;font-weight:bold;">${r[0]}</td>
            <td style="font-family:monospace;font-weight:bold;color:#065f46;">${r[1]}</td>
            <td>${r[2]}</td>
            <td style="text-align:right;font-family:monospace;">${r[3]}</td>
            <td style="text-align:right;font-family:monospace;">${r[4]}</td>
            <td style="text-align:right;font-family:monospace;font-weight:bold;">${r[5]}</td>
          </tr>
        `
          )
          .join('')}
        <tr style="background:#e6f4ea;border-top:1px dashed #047857;font-weight:bold;">
          <td colspan="3" style="padding:5px 8px;text-align:right;font-size:10px;text-transform:uppercase;color:#064e3b;">${subtotalLabel}:</td>
          <td style="text-align:right;font-family:monospace;font-size:10px;">${debitSub}</td>
          <td style="text-align:right;font-family:monospace;font-size:10px;">${creditSub}</td>
          <td style="text-align:right;font-family:monospace;font-size:10px;">${totalSub}</td>
        </tr>
      `;
    };

    const sReturnsRows: any[] = [];
    salesReturns.forEach(inv => {
      inv.items.forEach(item => {
        sReturnsRows.push([
          getAccountCode(inv.accountName),
          inv.invoiceNo,
          `${inv.accountName} - ${item.productName} (${item.quantity} ${item.unit} @ ${item.rate})`,
          '',
          item.amount ? Number(item.amount).toLocaleString() : '',
          inv.netTotal ? Number(inv.netTotal).toLocaleString() : ''
        ]);
      });
    });

    const pReturnsRows: any[] = [];
    purchaseReturns.forEach(inv => {
      inv.items.forEach(item => {
        pReturnsRows.push([
          getAccountCode(inv.accountName),
          inv.invoiceNo,
          `${inv.accountName} - ${item.productName} (${item.quantity} ${item.unit} @ ${item.rate})`,
          item.amount ? Number(item.amount).toLocaleString() : '',
          '',
          inv.netTotal ? Number(inv.netTotal).toLocaleString() : ''
        ]);
      });
    });

    const paymentRows: any[] = [];
    payments.forEach(v => {
      paymentRows.push([
        getAccountCode(v.lines?.[1]?.accountName || ''),
        v.voucherNo,
        `${v.lines?.[1]?.accountName || 'Cash Payment'} - ${v.narration || ''}`,
        v.totalAmount ? Number(v.totalAmount).toLocaleString() : '',
        '',
        ''
      ]);
    });

    const receiptRows: any[] = [];
    receipts.forEach(v => {
      receiptRows.push([
        getAccountCode(v.lines?.[0]?.accountName || ''),
        v.voucherNo,
        `${v.lines?.[0]?.accountName || 'Cash Receipt'} - ${v.narration || ''}`,
        '',
        v.totalAmount ? Number(v.totalAmount).toLocaleString() : '',
        ''
      ]);
    });

    const journalRows: any[] = [];
    journals.forEach(v => {
      v.lines.forEach(l => {
        journalRows.push([
          getAccountCode(l.accountName),
          v.voucherNo,
          `${l.accountName} - ${l.description || v.narration || 'Journal Entry'}`,
          l.debit ? Number(l.debit).toLocaleString() : '',
          l.credit ? Number(l.credit).toLocaleString() : '',
          ''
        ]);
      });
    });

    const purchaseRows: any[] = [];
    purchases.forEach(inv => {
      inv.items.forEach(item => {
        purchaseRows.push([
          getAccountCode(inv.accountName),
          inv.invoiceNo,
          `${inv.accountName} - ${item.productName} (${item.quantity} ${item.unit} @ ${item.rate})`,
          item.amount ? Number(item.amount).toLocaleString() : '',
          '',
          inv.netTotal ? Number(inv.netTotal).toLocaleString() : ''
        ]);
      });
    });

    const salesRows: any[] = [];
    sales.forEach(inv => {
      inv.items.forEach(item => {
        salesRows.push([
          getAccountCode(inv.accountName),
          inv.invoiceNo,
          `${inv.accountName} - ${item.productName} (${item.quantity} ${item.unit} @ ${item.rate})`,
          '',
          item.amount ? Number(item.amount).toLocaleString() : '',
          inv.netTotal ? Number(inv.netTotal).toLocaleString() : ''
        ]);
      });
    });

    sectionsHtml += renderSection('Sales', salesRows, 'Sub Total - Sales', '', '', sales.reduce((s, i) => s + i.netTotal, 0).toLocaleString());
    sectionsHtml += renderSection('Sales Returns', sReturnsRows, 'Sub Total - Sales Returns', '', '', salesReturns.reduce((s, i) => s + i.netTotal, 0).toLocaleString());
    sectionsHtml += renderSection('Purchases (Cash & Credit)', purchaseRows, 'Sub Total - Purchases', '', '', purchases.reduce((s, i) => s + i.netTotal, 0).toLocaleString());
    sectionsHtml += renderSection('Purchase Returns', pReturnsRows, 'Sub Total - Purchase Returns', '', '', purchaseReturns.reduce((s, i) => s + i.netTotal, 0).toLocaleString());
    sectionsHtml += renderSection('Payments (Cash Payment Vouchers)', paymentRows, 'Sub Total - Payments (CPV)', payments.reduce((s, v) => s + v.totalAmount, 0).toLocaleString(), '', '');
    sectionsHtml += renderSection('Receipts (Cash Receipt Vouchers)', receiptRows, 'Sub Total - Receipts (CRV)', '', receipts.reduce((s, v) => s + v.totalAmount, 0).toLocaleString(), '');
    sectionsHtml += renderSection(
      'Journal Vouchers',
      journalRows,
      'Sub Total - Journal Vouchers (JV)',
      journals.reduce((sum, v) => sum + (v.lines?.reduce((s, l) => s + (l.debit || 0), 0) || 0), 0).toLocaleString(),
      journals.reduce((sum, v) => sum + (v.lines?.reduce((s, l) => s + (l.credit || 0), 0) || 0), 0).toLocaleString(),
      ''
    );

    return `
      <div>
        ${headerHtml}
        <table>
          <thead>
            <tr>
              <th style="width:75px;">Code</th>
              <th style="width:110px;">Doc / Inv #</th>
              <th>Description & Account Head</th>
              <th style="width:105px;text-align:right;">Debit (PKR)</th>
              <th style="width:105px;text-align:right;">Credit (PKR)</th>
              <th style="width:115px;text-align:right;">Total (PKR)</th>
            </tr>
          </thead>
          <tbody>
            ${sectionsHtml}
          </tbody>
        </table>

        <div style="margin-top:14px;padding:10px 14px;background:#f9fafb;border:1.5px solid #d1d5db;border-radius:6px;display:flex;flex-wrap:wrap;justify-content:space-between;gap:12px;font-size:11px;">
          <div><strong>Today Expenses:</strong> <span style="font-family:monospace;font-weight:bold;color:#b91c1c;">PKR ${totalExps.toLocaleString()}</span></div>
          <div><strong>Today Profit:</strong> <span style="font-family:monospace;font-weight:bold;color:#065f46;">PKR ${todayProfit.toLocaleString()}</span></div>
          <div><strong>Cash Sales:</strong> <span style="font-family:monospace;font-weight:bold;color:#064e3b;">PKR ${totalCashSales.toLocaleString()}</span></div>
          <div><strong>Credit Sales:</strong> <span style="font-family:monospace;font-weight:bold;color:#047857;">PKR ${totalCreditSales.toLocaleString()}</span></div>
          <div><strong>Cash in Hand (${dateFrom}):</strong> <span style="font-family:monospace;font-weight:bold;color:#1e3a8a;">PKR ${cashBalFrom.toLocaleString()}</span></div>
          <div><strong>Cash in Hand (${dateTo}):</strong> <span style="font-family:monospace;font-weight:bold;color:#1e3a8a;">PKR ${cashBalTo.toLocaleString()}</span></div>
        </div>

        ${buildStandardReportFooterHtml(compName)}
      </div>
    `;
  };

  const handlePrint = () => {
    const compName = companyProfile?.companyName || 'AUGUSTA SEED COMPANY';
    const htmlContent = buildDailyReportHtml();
    printReportDirect({
      title: `${compName} - Daily Transaction Report`,
      htmlContent,
      landscape: true
    });
  };

  const exportPdf = async () => {
    const htmlContent = buildDailyReportHtml();
    await downloadPdfFromReportHtml({
      htmlContent,
      filename: `Daily_Transaction_Report_${dateFrom}_to_${dateTo}.pdf`,
      landscape: true
    });
  };

  const exportExcel = () => {
    const wsData: any[] = [];
    filteredInvoices.forEach(inv => {
      inv.items.forEach(item => {
        wsData.push({
          Date: inv.date,
          Code: getAccountCode(inv.accountName),
          'Doc No': inv.invoiceNo,
          Type: inv.invoiceType,
          'Account / Party': inv.accountName,
          'Product / Details': `${item.productName} (${item.quantity} ${item.unit} @ ${item.rate})`,
          'Item Amount': item.amount,
          'Invoice Total': inv.netTotal
        });
      });
    });

    filteredVouchers.forEach(v => {
      v.lines.forEach(l => {
        wsData.push({
          Date: v.date,
          Code: getAccountCode(l.accountName),
          'Doc No': v.voucherNo,
          Type: v.voucherType,
          'Account / Party': l.accountName,
          'Product / Details': l.description || v.narration,
          Debit: l.debit,
          Credit: l.credit
        });
      });
    });

    const worksheet = XLSX.utils.json_to_sheet(wsData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Daily Transactions');
    XLSX.writeFile(workbook, `daily-transactions-${dateFrom}-to-${dateTo}.xlsx`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4 bg-white p-6 rounded-xl border border-gray-200 shadow-xs">
        <div>
          <h2 className="text-2xl font-black text-gray-900 tracking-tight">DAILY TRANSACTION REPORT</h2>
          <p className="text-sm text-gray-500 mt-0.5">{companyProfile?.companyName || 'AUGUSTA SEED COMPANY'} • Period: {dateFrom} to {dateTo}</p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center space-x-1.5 bg-emerald-700 hover:bg-emerald-800 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors shadow-sm cursor-pointer"
            title="Print directly to Default Printer"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>
          <button
            type="button"
            onClick={exportPdf}
            className="flex items-center space-x-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 px-4 py-2 rounded-lg text-sm font-semibold border border-emerald-200 cursor-pointer"
            title="Download PDF matching print layout"
          >
            <Download className="w-4 h-4" />
            <span>Export PDF</span>
          </button>
          <button
            onClick={exportExcel}
            className="flex items-center space-x-1.5 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-lg text-sm font-semibold shadow-sm transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export Excel</span>
          </button>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-xs grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Date From</label>
          <input
            type="date"
            value={dateFrom}
            onChange={e => setDateFrom(e.target.value)}
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Date To</label>
          <input
            type="date"
            value={dateTo}
            onChange={e => setDateTo(e.target.value)}
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Search Details / Party</label>
          <input
            type="text"
            placeholder="Search invoice no, party, product..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden"
          />
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-300 shadow-sm overflow-hidden font-mono text-xs">
        <div className="bg-emerald-950 text-white px-6 py-3 flex justify-between items-center font-sans">
          <span className="font-bold">ITTEHAD SEED CORPORATION - DAILY TRANSACTION LEDGER</span>
          <span>DATE: {dateFrom}</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-100 border-b border-gray-300 text-gray-700 font-bold uppercase">
                <th className="py-2.5 px-3 border-r border-gray-300 w-20">CODE:</th>
                <th className="py-2.5 px-3 border-r border-gray-300 w-44">INV & DOC</th>
                <th className="py-2.5 px-3 border-r border-gray-300">DESCRIPTION AND ACCOUNT HEAD</th>
                <th className="py-2.5 px-3 border-r border-gray-300 text-right w-28">DEBIT:</th>
                <th className="py-2.5 px-3 border-r border-gray-300 text-right w-28">CREDIT:</th>
                <th className="py-2.5 px-3 text-right w-28">TOTAL:</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {sales.length > 0 && (
                <>
                  <tr className="bg-blue-50 font-bold text-blue-900">
                    <td colSpan={6} className="py-1.5 px-3 uppercase">SALES</td>
                  </tr>
                  {sales.map(inv =>
                    inv.items.map((item, idx) => (
                      <tr key={`${inv.id}-${idx}`} className="hover:bg-gray-50">
                        <td className="py-1.5 px-3 border-r border-gray-200 font-bold text-emerald-800">
                          {getAccountCode(inv.accountName)}
                        </td>
                        <td className="py-1.5 px-3 border-r border-gray-200 font-semibold">{inv.invoiceNo}</td>
                        <td className="py-1.5 px-3 border-r border-gray-200">
                          {item.quantity} {item.unit} @ {item.rate} {item.productName} — {inv.accountName}
                        </td>
                        <td className="py-1.5 px-3 border-r border-gray-200 text-right"></td>
                        <td className="py-1.5 px-3 border-r border-gray-200 text-right">{item.amount.toLocaleString()}</td>
                        <td className="py-1.5 px-3 text-right font-bold">
                          {idx === 0 ? inv.netTotal.toLocaleString() : ''}
                        </td>
                      </tr>
                    ))
                  )}
                  <tr className="bg-blue-100/70 font-bold text-blue-950 border-t border-blue-200">
                    <td colSpan={3} className="py-2 px-3 border-r border-gray-200 text-right uppercase">Sub Total - Sales:</td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right"></td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right"></td>
                    <td className="py-2 px-3 text-right">{sales.reduce((s, i) => s + i.netTotal, 0).toLocaleString()}</td>
                  </tr>
                </>
              )}

              {salesReturns.length > 0 && (
                <>
                  <tr className="bg-amber-50 font-bold text-amber-900">
                    <td colSpan={6} className="py-1.5 px-3 uppercase">SALES RETURN</td>
                  </tr>
                  {salesReturns.map(inv =>
                    inv.items.map((item, idx) => (
                      <tr key={`${inv.id}-${idx}`} className="hover:bg-gray-50">
                        <td className="py-1.5 px-3 border-r border-gray-200 font-bold text-emerald-800">
                          {getAccountCode(inv.accountName)}
                        </td>
                        <td className="py-1.5 px-3 border-r border-gray-200 font-semibold">{inv.invoiceNo}</td>
                        <td className="py-1.5 px-3 border-r border-gray-200">
                          {item.quantity} {item.unit} @ {item.rate} {item.productName} — {inv.accountName}
                        </td>
                        <td className="py-1.5 px-3 border-r border-gray-200 text-right"></td>
                        <td className="py-1.5 px-3 border-r border-gray-200 text-right">{item.amount.toLocaleString()}</td>
                        <td className="py-1.5 px-3 text-right font-bold">
                          {idx === 0 ? inv.netTotal.toLocaleString() : ''}
                        </td>
                      </tr>
                    ))
                  )}
                  <tr className="bg-amber-100/70 font-bold text-amber-950 border-t border-amber-200">
                    <td colSpan={3} className="py-2 px-3 border-r border-gray-200 text-right uppercase">Sub Total - Sales Return:</td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right"></td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right"></td>
                    <td className="py-2 px-3 text-right">{salesReturns.reduce((s, i) => s + i.netTotal, 0).toLocaleString()}</td>
                  </tr>
                </>
              )}

              {purchases.length > 0 && (
                <>
                  <tr className="bg-indigo-50 font-bold text-indigo-900">
                    <td colSpan={6} className="py-1.5 px-3 uppercase">PURCHASES</td>
                  </tr>
                  {purchases.map(inv =>
                    inv.items.map((item, idx) => (
                      <tr key={`${inv.id}-${idx}`} className="hover:bg-gray-50">
                        <td className="py-1.5 px-3 border-r border-gray-200 font-bold text-emerald-800">
                          {getAccountCode(inv.accountName)}
                        </td>
                        <td className="py-1.5 px-3 border-r border-gray-200 font-semibold">{inv.invoiceNo}</td>
                        <td className="py-1.5 px-3 border-r border-gray-200">
                          {item.quantity} {item.unit} @ {item.rate} {item.productName} — {inv.accountName}
                        </td>
                        <td className="py-1.5 px-3 border-r border-gray-200 text-right">{item.amount.toLocaleString()}</td>
                        <td className="py-1.5 px-3 border-r border-gray-200 text-right"></td>
                        <td className="py-1.5 px-3 text-right font-bold">
                          {idx === 0 ? inv.netTotal.toLocaleString() : ''}
                        </td>
                      </tr>
                    ))
                  )}
                  <tr className="bg-indigo-100/70 font-bold text-indigo-950 border-t border-indigo-200">
                    <td colSpan={3} className="py-2 px-3 border-r border-gray-200 text-right uppercase">Sub Total - Purchases:</td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right"></td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right"></td>
                    <td className="py-2 px-3 text-right">{purchases.reduce((s, i) => s + i.netTotal, 0).toLocaleString()}</td>
                  </tr>
                </>
              )}

              {purchaseReturns.length > 0 && (
                <>
                  <tr className="bg-purple-50 font-bold text-purple-900">
                    <td colSpan={6} className="py-1.5 px-3 uppercase">PURCHASE RETURN</td>
                  </tr>
                  {purchaseReturns.map(inv =>
                    inv.items.map((item, idx) => (
                      <tr key={`${inv.id}-${idx}`} className="hover:bg-gray-50">
                        <td className="py-1.5 px-3 border-r border-gray-200 font-bold text-emerald-800">
                          {getAccountCode(inv.accountName)}
                        </td>
                        <td className="py-1.5 px-3 border-r border-gray-200 font-semibold">{inv.invoiceNo}</td>
                        <td className="py-1.5 px-3 border-r border-gray-200">
                          {item.quantity} {item.unit} @ {item.rate} {item.productName} — {inv.accountName}
                        </td>
                        <td className="py-1.5 px-3 border-r border-gray-200 text-right">{item.amount.toLocaleString()}</td>
                        <td className="py-1.5 px-3 border-r border-gray-200 text-right"></td>
                        <td className="py-1.5 px-3 text-right font-bold">
                          {idx === 0 ? inv.netTotal.toLocaleString() : ''}
                        </td>
                      </tr>
                    ))
                  )}
                  <tr className="bg-purple-100/70 font-bold text-purple-950 border-t border-purple-200">
                    <td colSpan={3} className="py-2 px-3 border-r border-gray-200 text-right uppercase">Sub Total - Purchase Return:</td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right"></td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right"></td>
                    <td className="py-2 px-3 text-right">{purchaseReturns.reduce((s, i) => s + i.netTotal, 0).toLocaleString()}</td>
                  </tr>
                </>
              )}

              {payments.length > 0 && (
                <>
                  <tr className="bg-red-50 font-bold text-red-900">
                    <td colSpan={6} className="py-1.5 px-3 uppercase">PAYMENTS (CPV)</td>
                  </tr>
                  {payments.map(v => (
                    <tr key={v.id} className="hover:bg-gray-50">
                      <td className="py-1.5 px-3 border-r border-gray-200 font-bold text-emerald-800">
                        {getAccountCode(v.lines?.[1]?.accountName || '')}
                      </td>
                      <td className="py-1.5 px-3 border-r border-gray-200 font-semibold">{v.voucherNo}</td>
                      <td className="py-1.5 px-3 border-r border-gray-200">
                        {v.narration || 'Cash Payment'} — {v.lines?.[1]?.accountName}
                      </td>
                      <td className="py-1.5 px-3 border-r border-gray-200 text-right font-bold">
                        {v.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-1.5 px-3 border-r border-gray-200 text-right"></td>
                      <td className="py-1.5 px-3 text-right"></td>
                    </tr>
                  ))}
                  <tr className="bg-red-100/70 font-bold text-red-950 border-t border-red-200">
                    <td colSpan={3} className="py-2 px-3 border-r border-gray-200 text-right uppercase">Sub Total - Payments (CPV):</td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right">{payments.reduce((s, v) => s + v.totalAmount, 0).toLocaleString()}</td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right"></td>
                    <td className="py-2 px-3 text-right"></td>
                  </tr>
                </>
              )}

              {receipts.length > 0 && (
                <>
                  <tr className="bg-emerald-50 font-bold text-emerald-900">
                    <td colSpan={6} className="py-1.5 px-3 uppercase">RECEIPTS (CRV)</td>
                  </tr>
                  {receipts.map(v => (
                    <tr key={v.id} className="hover:bg-gray-50">
                      <td className="py-1.5 px-3 border-r border-gray-200 font-bold text-emerald-800">
                        {getAccountCode(v.lines?.[0]?.accountName || '')}
                      </td>
                      <td className="py-1.5 px-3 border-r border-gray-200 font-semibold">{v.voucherNo}</td>
                      <td className="py-1.5 px-3 border-r border-gray-200">
                        {v.narration || 'Cash Receipt'} — {v.lines?.[0]?.accountName}
                      </td>
                      <td className="py-1.5 px-3 border-r border-gray-200 text-right"></td>
                      <td className="py-1.5 px-3 border-r border-gray-200 text-right font-bold">
                        {v.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-1.5 px-3 text-right"></td>
                    </tr>
                  ))}
                  <tr className="bg-emerald-100/70 font-bold text-emerald-950 border-t border-emerald-200">
                    <td colSpan={3} className="py-2 px-3 border-r border-gray-200 text-right uppercase">Sub Total - Receipts (CRV):</td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right"></td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right">{receipts.reduce((s, v) => s + v.totalAmount, 0).toLocaleString()}</td>
                    <td className="py-2 px-3 text-right"></td>
                  </tr>
                </>
              )}

              {journals.length > 0 && (
                <>
                  <tr className="bg-teal-50 font-bold text-teal-900">
                    <td colSpan={6} className="py-1.5 px-3 uppercase">JOURNAL VOUCHERS (JV)</td>
                  </tr>
                  {journals.map(v =>
                    v.lines?.map((l, idx) => (
                      <tr key={`${v.id}-${idx}`} className="hover:bg-gray-50">
                        <td className="py-1.5 px-3 border-r border-gray-200 font-bold text-emerald-800">
                          {getAccountCode(l.accountName)}
                        </td>
                        <td className="py-1.5 px-3 border-r border-gray-200 font-semibold">{v.voucherNo}</td>
                        <td className="py-1.5 px-3 border-r border-gray-200">
                          {l.accountName} — {l.description || v.narration || 'Journal Entry'}
                        </td>
                        <td className="py-1.5 px-3 border-r border-gray-200 text-right font-bold">
                          {l.debit ? l.debit.toLocaleString() : ''}
                        </td>
                        <td className="py-1.5 px-3 border-r border-gray-200 text-right font-bold">
                          {l.credit ? l.credit.toLocaleString() : ''}
                        </td>
                        <td className="py-1.5 px-3 text-right"></td>
                      </tr>
                    ))
                  )}
                  <tr className="bg-teal-100/70 font-bold text-teal-950 border-t border-teal-200">
                    <td colSpan={3} className="py-2 px-3 border-r border-gray-200 text-right uppercase">Sub Total - Journal Vouchers (JV):</td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right">
                      {journals.reduce((sum, v) => sum + (v.lines?.reduce((s, l) => s + (l.debit || 0), 0) || 0), 0).toLocaleString()}
                    </td>
                    <td className="py-2 px-3 border-r border-gray-200 text-right">
                      {journals.reduce((sum, v) => sum + (v.lines?.reduce((s, l) => s + (l.credit || 0), 0) || 0), 0).toLocaleString()}
                    </td>
                    <td className="py-2 px-3 text-right"></td>
                  </tr>
                </>
              )}
            </tbody>
          </table>
        </div>

        {/* Summary Footer Box */}
        <div className="bg-gray-100 border-t border-gray-300 p-4 grid grid-cols-2 md:grid-cols-6 gap-4 font-sans text-xs">
          <div>
            <p className="text-gray-500 font-semibold uppercase">Today Expenses</p>
            <p className="text-base font-bold text-red-700">PKR {totalExps.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-gray-500 font-semibold uppercase">Today Profit / Net</p>
            <p className={`text-base font-bold ${todayProfit >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
              PKR {todayProfit.toLocaleString()}
            </p>
          </div>
          <div>
            <p className="text-gray-500 font-semibold uppercase">Cash Sales</p>
            <p className="text-base font-bold text-gray-800">PKR {totalCashSales.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-gray-500 font-semibold uppercase">Credit Sales</p>
            <p className="text-base font-bold text-gray-800">PKR {totalCreditSales.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-gray-500 font-semibold uppercase">Cash in Hand ({dateFrom})</p>
            <p className="text-base font-bold text-blue-900">PKR {cashBalFrom.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-gray-500 font-semibold uppercase">Cash in Hand ({dateTo})</p>
            <p className="text-base font-bold text-blue-900">PKR {cashBalTo.toLocaleString()}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
