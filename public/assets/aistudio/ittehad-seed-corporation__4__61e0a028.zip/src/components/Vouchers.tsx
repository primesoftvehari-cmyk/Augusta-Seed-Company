import React, { useState, useEffect, useRef } from 'react';
import { db } from '../services/db';
import { Voucher, VoucherType, Account, SalesStaff, UserProfile, VoucherLine } from '../types';
import { Receipt, Plus, Trash2, Save, Printer, Edit, X, Search, Calendar, Filter, RotateCcw, Download } from 'lucide-react';
import {
  printReportDirect,
  downloadPdfFromReportHtml
} from '../utils/reportPrinter';
import { formatDate } from '../utils/dateUtils';

export const VouchersComponent: React.FC<{ currentUser: UserProfile; defaultType?: VoucherType }> = ({
  currentUser,
  defaultType = 'CASH_PAYMENT'
}) => {
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [staffList, setStaffList] = useState<SalesStaff[]>([]);
  const [companyProfile, setCompanyProfile] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<VoucherType>(defaultType);

  // Form state
  const formatToDdMmYyyy = (isoDate: string) => {
    if (!isoDate) return '';
    const parts = isoDate.split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    return isoDate;
  };

  const parseToIsoDate = (str: string) => {
    const clean = str.trim().replace(/-/g, '/');
    const parts = clean.split('/');
    if (parts.length === 3) {
      const [d, m, y] = parts;
      if (y.length === 4 && m.length <= 2 && d.length <= 2) {
        return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
      }
    }
    return str;
  };

  const todayIso = new Date().toISOString().split('T')[0];
  const [voucherNo, setVoucherNo] = useState('');
  const [date, setDate] = useState(todayIso);
  const [dateDisplayVal, setDateDisplayVal] = useState(formatToDdMmYyyy(todayIso));
  const [narration, setNarration] = useState('');
  const [debitNarration, setDebitNarration] = useState('');
  const [creditNarration, setCreditNarration] = useState('');
  const [salesStaff, setSalesStaff] = useState('');
  const [debitAccountId, setDebitAccountId] = useState('');
  const [creditAccountId, setCreditAccountId] = useState('');
  const [debitSearch, setDebitSearch] = useState('');
  const [creditSearch, setCreditSearch] = useState('');
  const [amount, setAmount] = useState<number>(0);
  const [isCreditFixed, setIsCreditFixed] = useState<boolean>(false);
  const [isDebitFixed, setIsDebitFixed] = useState<boolean>(false);
  const [editingVoucher, setEditingVoucher] = useState<Voucher | null>(null);

  // Refs for focus management
  const dateInputRef = useRef<HTMLInputElement>(null);
  const debitSearchRef = useRef<HTMLInputElement>(null);
  const debitSelectRef = useRef<HTMLSelectElement>(null);
  const narrationInputRef = useRef<HTMLInputElement>(null);
  const amountInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    dateInputRef.current?.focus();
  }, []);

  // Date-wise Search and Filter states
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');
  const [searchKeyword, setSearchKeyword] = useState('');

  const handleEdit = (v: Voucher) => {
    setEditingVoucher(v);
    setVoucherNo(v.voucherNo);
    setDate(v.date);
    setDateDisplayVal(formatToDdMmYyyy(v.date));
    setNarration(v.narration);
    setSalesStaff(v.salesStaff || '');
    if (v.lines && v.lines.length >= 2) {
      setDebitAccountId(v.lines[0].accountId);
      setCreditAccountId(v.lines[1].accountId);
      setAmount(v.lines[0].debit || v.lines[1].credit || 0);
      if (v.voucherType === 'JOURNAL') {
        setDebitNarration(v.lines[0].description || '');
        setCreditNarration(v.lines[1].description || '');
      }
    }
  };

  const handleCancelEdit = () => {
    setEditingVoucher(null);
    setVoucherNo(`${activeTab.substring(0, 3)}-${Math.floor(1000 + Math.random() * 9000)}`);
    const tIso = new Date().toISOString().split('T')[0];
    setDate(tIso);
    setDateDisplayVal(formatToDdMmYyyy(tIso));
    setNarration('');
    setDebitNarration('');
    setCreditNarration('');
    setSalesStaff('');
    setDebitAccountId('');
    setDebitSearch('');
    setCreditSearch('');
    setAmount(0);
  };

  useEffect(() => {
    if (isDebitFixed && debitAccountId) {
      localStorage.setItem(`ittehad_fixed_debit_acc_${activeTab}`, debitAccountId);
    }
  }, [debitAccountId, isDebitFixed, activeTab]);

  const handleToggleFixDebit = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fixed = e.target.checked;
    setIsDebitFixed(fixed);
    if (fixed && debitAccountId) {
      localStorage.setItem(`ittehad_fixed_debit_acc_${activeTab}`, debitAccountId);
    } else {
      localStorage.removeItem(`ittehad_fixed_debit_acc_${activeTab}`);
    }
  };

  useEffect(() => {
    if (isCreditFixed && creditAccountId) {
      localStorage.setItem(`ittehad_fixed_credit_acc_${activeTab}`, creditAccountId);
    }
  }, [creditAccountId, isCreditFixed, activeTab]);

  const handleToggleFixCredit = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fixed = e.target.checked;
    setIsCreditFixed(fixed);
    if (fixed && creditAccountId) {
      localStorage.setItem(`ittehad_fixed_credit_acc_${activeTab}`, creditAccountId);
    } else {
      localStorage.removeItem(`ittehad_fixed_credit_acc_${activeTab}`);
    }
  };

  useEffect(() => {
    loadData();
    setTimeout(() => {
      dateInputRef.current?.focus();
    }, 50);
  }, [activeTab]);

  useEffect(() => {
    const debAcc = accounts.find(a => a.id === debitAccountId);
    const credAcc = accounts.find(a => a.id === creditAccountId);
    const debName = debAcc ? debAcc.name : '';
    const credName = credAcc ? credAcc.name : '';

    if (activeTab === 'JOURNAL') {
      setDebitNarration(`JV.${voucherNo} ${debName} from. ${credName}`);
      setCreditNarration(`JV.${voucherNo} ${credName} from. ${debName}`);
    } else if (activeTab === 'CASH_RECEIPT' && credName) {
      setNarration(`from.${credName}`);
    } else if (activeTab === 'CASH_PAYMENT' && debName) {
      setNarration(`Cash paid to.${debName}`);
    }
  }, [debitAccountId, creditAccountId, voucherNo, activeTab, accounts]);

  const loadData = async (preservedDate?: string) => {
    const list = await db.getVouchers();
    const accs = await db.getAccounts();
    const staff = await db.getSalesStaff();
    const profile = await db.getCompanyProfile();
    setVouchers(list.filter(v => v.voucherType === activeTab));
    setAccounts(accs);
    setStaffList(staff);
    setCompanyProfile(profile);
    setVoucherNo(`${activeTab.substring(0, 3)}-${Math.floor(1000 + Math.random() * 9000)}`);
    const tIso = preservedDate || date || new Date().toISOString().split('T')[0];
    setDate(tIso);
    setDateDisplayVal(formatToDdMmYyyy(tIso));
    setNarration('');
    setDebitNarration('');
    setCreditNarration('');
    setSalesStaff('');
    setAmount(0);
    setEditingVoucher(null);

    if (activeTab === 'CASH_PAYMENT') {
      const cashAcc = accs.find(a => a.code === 'ACC-10000' || a.name.toUpperCase().includes('CASH IN HAND'));
      if (cashAcc) {
        setCreditAccountId(cashAcc.id);
        setIsCreditFixed(true);
      }
    } else {
      const savedFixed = localStorage.getItem(`ittehad_fixed_credit_acc_${activeTab}`);
      if (savedFixed) {
        setCreditAccountId(savedFixed);
        setIsCreditFixed(true);
      } else {
        setCreditAccountId('');
        setIsCreditFixed(false);
      }
    }

    if (activeTab === 'CASH_RECEIPT') {
      const cashAcc = accs.find(a => a.code === 'ACC-10000' || a.name.toUpperCase().includes('CASH IN HAND'));
      if (cashAcc) {
        setDebitAccountId(cashAcc.id);
        setIsDebitFixed(true);
      }
    } else {
      const savedFixedDebit = localStorage.getItem(`ittehad_fixed_debit_acc_${activeTab}`);
      if (savedFixedDebit) {
        setDebitAccountId(savedFixedDebit);
        setIsDebitFixed(true);
      } else {
        setDebitAccountId('');
        setIsDebitFixed(false);
      }
    }
  };

  const buildVoucherHtml = (v: Voucher): string => {
    const compName = companyProfile?.companyName || 'AUGUSTA SEED COMPANY';
    const compAddr = companyProfile?.headOfficeAddress || 'UNITED FARM ROAD, GULSHAN-E-ALI BY PASS, SAHIWAL';
    const compPhone = companyProfile?.phone || companyProfile?.mobile || '03023576036';
    const logoUrl = companyProfile?.logoUrl || '/logoittehad.png';

    const getVoucherTitle = () => {
      switch (v.voucherType) {
        case 'CASH_PAYMENT': return 'CASH PAYMENT VOUCHER (CPV)';
        case 'CASH_RECEIPT': return 'CASH RECEIPT VOUCHER (CRV)';
        case 'JOURNAL': return 'JOURNAL VOUCHER (JV)';
        default: return 'FINANCIAL VOUCHER';
      }
    };

    let totalDebit = 0;
    let totalCredit = 0;
    const linesHtml = (v.lines || [])
      .map(line => {
        const acc = accounts.find(a => a.id === line.accountId || a.name === line.accountName);
        const code = acc?.code || '1000';
        const name = acc?.name || line.accountName;
        const dr = Number(line.debit || 0);
        const cr = Number(line.credit || 0);
        totalDebit += dr;
        totalCredit += cr;
        return `
          <tr>
            <td style="font-family:monospace;font-weight:bold;color:#065f46;">${code}</td>
            <td style="font-weight:600;">${name}</td>
            <td>${line.description || v.narration || '-'}</td>
            <td style="text-align:right;font-family:monospace;">${dr > 0 ? dr.toLocaleString() : '-'}</td>
            <td style="text-align:right;font-family:monospace;">${cr > 0 ? cr.toLocaleString() : '-'}</td>
          </tr>
        `;
      })
      .join('');

    return `
      <div>
        <div style="display:flex;align-items:center;justify-content:space-between;border-bottom:2.5px solid #064e3b;padding-bottom:10px;margin-bottom:12px;">
          <div style="display:flex;align-items:center;gap:12px;">
            <img src="${logoUrl}" style="width:54px;height:54px;object-fit:contain;" alt="Logo" onerror="this.style.display='none'" />
            <div>
              <h1 style="margin:0;font-size:19px;font-weight:900;color:#064e3b;text-transform:uppercase;letter-spacing:0.5px;">${compName}</h1>
              <div style="font-size:11px;color:#374151;margin-top:2px;">${compAddr} &bull; PH: ${compPhone}</div>
            </div>
          </div>
          <div style="text-align:center;border:2px solid #064e3b;background:#f0fdf4;padding:6px 14px;border-radius:6px;">
            <span style="font-weight:900;color:#064e3b;font-size:13px;text-transform:uppercase;letter-spacing:1px;">${getVoucherTitle()}</span>
          </div>
        </div>

        <div style="display:flex;justify-content:space-between;margin-bottom:12px;font-size:11.5px;line-height:1.5;">
          <div>
            <div><strong>VOUCHER NO:</strong> <span style="font-family:monospace;font-weight:bold;color:#064e3b;">${v.voucherNo}</span></div>
            <div><strong>DATE:</strong> <span style="font-family:monospace;">${formatDate(v.date)}</span></div>
            ${v.salesStaff ? `<div><strong>SALES OFFICER:</strong> <span>${v.salesStaff}</span></div>` : ''}
          </div>
          <div style="text-align:right;">
            <div><strong>TOTAL AMOUNT:</strong> <span style="font-family:monospace;font-weight:900;color:#064e3b;font-size:13px;">PKR ${Number(v.totalAmount).toLocaleString()}</span></div>
            <div><strong>PREPARED BY:</strong> <span style="text-transform:uppercase;">${v.createdBy || 'Staff'}</span></div>
          </div>
        </div>

        <div style="margin-bottom:12px;background:#f9fafb;border:1px solid #d1d5db;border-radius:6px;padding:8px 12px;font-size:11.5px;">
          <strong>Narration / Description:</strong> ${v.narration || 'N/A'}
        </div>

        <table>
          <thead>
            <tr>
              <th style="width:85px;">Code</th>
              <th>Account Head / Title</th>
              <th>Particulars</th>
              <th style="width:120px;text-align:right;">Debit (PKR)</th>
              <th style="width:120px;text-align:right;">Credit (PKR)</th>
            </tr>
          </thead>
          <tbody>
            ${linesHtml}
          </tbody>
          <tfoot>
            <tr>
              <td colspan="3" style="text-align:right;font-weight:bold;">Total Amount:</td>
              <td style="text-align:right;font-family:monospace;font-weight:bold;color:#064e3b;">PKR ${totalDebit.toLocaleString()}</td>
              <td style="text-align:right;font-family:monospace;font-weight:bold;color:#064e3b;">PKR ${totalCredit.toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>

        <div style="margin-top:35px;padding-top:14px;border-top:1px solid #9ca3af;display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:16px;font-size:10.5px;text-align:center;">
          <div>
            <div style="border-top:1.5px solid #111827;padding-top:4px;font-weight:bold;">Prepared By</div>
          </div>
          <div>
            <div style="border-top:1.5px solid #111827;padding-top:4px;font-weight:bold;">Verified By</div>
          </div>
          <div>
            <div style="border-top:1.5px solid #111827;padding-top:4px;font-weight:bold;">Accountant</div>
          </div>
          <div>
            <div style="border-top:1.5px solid #111827;padding-top:4px;font-weight:bold;">Authorized Officer</div>
          </div>
        </div>

        <div style="text-align:center;font-size:10px;color:#6b7280;margin-top:20px;border-top:1px dashed #d1d5db;padding-top:6px;">
          Official Voucher issued by ${compName} ERP System &bull; ${compAddr} &bull; PH: ${compPhone}
        </div>
      </div>
    `;
  };

  const handlePrintVoucher = (v: Voucher) => {
    const compName = companyProfile?.companyName || 'AUGUSTA SEED COMPANY';
    const htmlContent = buildVoucherHtml(v);
    printReportDirect({
      title: `${compName} - Voucher ${v.voucherNo}`,
      htmlContent,
      landscape: false
    });
  };

  const handleExportVoucherPdf = async (v: Voucher) => {
    const compName = companyProfile?.companyName || 'AUGUSTA SEED COMPANY';
    const htmlContent = buildVoucherHtml(v);
    await downloadPdfFromReportHtml({
      htmlContent,
      filename: `${compName.replace(/\s+/g, '_')}_Voucher_${v.voucherNo}.pdf`,
      landscape: false
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!debitAccountId || !creditAccountId) {
      alert('Please select both Debit and Credit accounts.');
      return;
    }
    if (debitAccountId === creditAccountId) {
      alert('Debit account and Credit account cannot be the same.');
      return;
    }
    if (amount <= 0) {
      alert('Please enter a valid voucher amount greater than 0.');
      return;
    }

    const debitAcc = accounts.find(a => a.id === debitAccountId);
    const creditAcc = accounts.find(a => a.id === creditAccountId);

    const lines: VoucherLine[] = [
      {
        accountId: debitAccountId,
        accountName: debitAcc ? debitAcc.name : '',
        description: activeTab === 'JOURNAL' ? debitNarration : narration,
        debit: amount,
        credit: 0
      },
      {
        accountId: creditAccountId,
        accountName: creditAcc ? creditAcc.name : '',
        description: activeTab === 'JOURNAL' ? creditNarration : narration,
        debit: 0,
        credit: amount
      }
    ];

    const newVoucher: Voucher = {
      id: editingVoucher ? editingVoucher.id : `vch_${Date.now()}`,
      voucherNo,
      voucherType: activeTab,
      date,
      salesStaff,
      lines,
      totalAmount: amount,
      narration: activeTab === 'JOURNAL' ? `${debitNarration} | ${creditNarration}` : narration,
      createdBy: currentUser.fullName,
      createdAt: editingVoucher ? editingVoucher.createdAt : new Date().toISOString()
    };

    await db.saveVoucher(newVoucher);
    alert(editingVoucher ? 'Voucher updated successfully!' : 'Voucher posted successfully!');
    const keptDate = date;
    setEditingVoucher(null);
    setVoucherNo(`${activeTab.substring(0, 3)}-${Math.floor(1000 + Math.random() * 9000)}`);
    setDate(keptDate);
    setDateDisplayVal(formatToDdMmYyyy(keptDate));
    setNarration('');
    setDebitNarration('');
    setCreditNarration('');
    setSalesStaff('');
    setAmount(0);
    dateInputRef.current?.focus();
    loadData(keptDate);
  };

  const handleDelete = async (id: string) => {
    if (currentUser.role !== 'ADMIN') {
      alert('Normal users cannot delete saved vouchers.');
      return;
    }
    if (confirm('Are you sure you want to delete this voucher?')) {
      await db.deleteVoucher(id);
      loadData();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">
            {activeTab === 'CASH_PAYMENT' && 'Cash Payment Voucher (CPV)'}
            {activeTab === 'CASH_RECEIPT' && 'Cash Receipt Voucher (CRV)'}
            {activeTab === 'JOURNAL' && 'Journal Voucher (JV)'}
          </h2>
          <p className="text-sm text-gray-500">Record financial receipts, payments, and double-entry general ledger journals</p>
        </div>
        <div className="flex space-x-2 bg-white p-1 rounded-xl border border-gray-200">
          <button
            onClick={() => setActiveTab('CASH_PAYMENT')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'CASH_PAYMENT' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Payment (CPV)
          </button>
          <button
            onClick={() => setActiveTab('CASH_RECEIPT')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'CASH_RECEIPT' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Receipt (CRV)
          </button>
          <button
            onClick={() => setActiveTab('JOURNAL')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'JOURNAL' ? 'bg-emerald-700 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Journal (JV)
          </button>
        </div>
      </div>

      <form onSubmit={handleSave} className="bg-white rounded-xl border border-gray-200 shadow-xs p-6 space-y-6">
        {editingVoucher && (
          <div className="flex items-center justify-between bg-amber-50 border border-amber-200 p-3 rounded-lg text-amber-900 text-sm">
            <span>Editing Voucher: <strong>{editingVoucher.voucherNo}</strong></span>
            <button type="button" onClick={handleCancelEdit} className="text-xs text-amber-800 underline font-semibold">
              Cancel Edit
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div>
            <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Voucher No</label>
            <input
              type="text"
              required
              value={voucherNo}
              onChange={e => setVoucherNo(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden font-mono font-bold"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Voucher Date (dd/mm/yyyy)</label>
            <input
              ref={dateInputRef}
              type="date"
              lang="en-GB"
              required
              value={date}
              onChange={e => {
                const val = e.target.value;
                setDate(val);
                setDateDisplayVal(formatToDdMmYyyy(val));
              }}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  if (activeTab === 'CASH_PAYMENT') {
                    debitSearchRef.current?.focus();
                  } else {
                    narrationInputRef.current?.focus();
                  }
                }
              }}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Sales Staff</label>
            <select
              value={salesStaff}
              onChange={e => setSalesStaff(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
            >
              <option value="">Select Sales Staff (Optional)...</option>
              {staffList.map(s => (
                <option key={s.id} value={s.staffName}>
                  {s.staffCode} - {s.staffName}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Narration / Remarks</label>
            <input
              ref={narrationInputRef}
              type="text"
              required={activeTab !== 'JOURNAL'}
              placeholder="Description of transaction..."
              value={narration}
              onChange={e => setNarration(e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden"
            />
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-gray-700">
            {activeTab === 'CASH_PAYMENT' && 'Cash Payment Details (Debit Account & Credit Cash/Bank Account)'}
            {activeTab === 'CASH_RECEIPT' && 'Cash Receipt Details (Debit Cash/Bank Account & Credit Account)'}
            {activeTab === 'JOURNAL' && 'Journal Entry Details (Debit Account & Credit Account)'}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold uppercase text-gray-600">
                  {activeTab === 'CASH_RECEIPT' ? 'Debit Account (Fixed Cash in Hand)' : 'Debit Account'}
                </label>
                {activeTab !== 'CASH_RECEIPT' && (
                  <label className="flex items-center space-x-1.5 text-xs text-emerald-700 cursor-pointer font-medium" title="Fix this debit account for rapid repetitive postings">
                    <input
                      type="checkbox"
                      checked={isDebitFixed}
                      onChange={handleToggleFixDebit}
                      className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                    />
                    <span>Fix Account</span>
                  </label>
                )}
              </div>
              {activeTab === 'CASH_RECEIPT' ? (
                <input
                  type="text"
                  disabled
                  value={(() => {
                    const dAcc = accounts.find(a => a.id === debitAccountId || a.code === 'ACC-10000');
                    return dAcc ? `${dAcc.code} - ${dAcc.name}` : 'ACC-10000 - CASH IN HAND';
                  })()}
                  className="w-full rounded-lg border border-gray-300 bg-gray-100 px-3 py-2 text-sm font-semibold text-gray-800"
                />
              ) : (
                <>
                  <input
                    ref={debitSearchRef}
                    type="text"
                    placeholder="Search debit account..."
                    value={debitSearch}
                    onChange={e => setDebitSearch(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        debitSelectRef.current?.focus();
                      }
                    }}
                    className="w-full rounded-lg border border-gray-300 px-3 py-1.5 text-xs mb-2 focus:border-emerald-600 focus:outline-hidden"
                  />
                  <select
                    ref={debitSelectRef}
                    required
                    value={debitAccountId}
                    onChange={e => {
                      const accId = e.target.value;
                      setDebitAccountId(accId);
                      if (isDebitFixed && accId) {
                        localStorage.setItem(`ittehad_fixed_debit_acc_${activeTab}`, accId);
                      }
                      const selAcc = accounts.find(a => a.id === accId);
                      const credAcc = accounts.find(a => a.id === creditAccountId);
                      if (activeTab === 'CASH_PAYMENT' && selAcc) {
                        setNarration(`Cash paid to.${selAcc.name}`);
                        amountInputRef.current?.focus();
                      } else if (activeTab === 'JOURNAL' && selAcc) {
                        setDebitNarration(`JV.${voucherNo} ${selAcc.name} from. ${credAcc ? credAcc.name : ''}`);
                      }
                    }}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
                  >
                    <option value="">Select Debit Account...</option>
                    {accounts
                      .filter(acc =>
                        acc.name.toLowerCase().includes(debitSearch.toLowerCase()) ||
                        acc.code.toLowerCase().includes(debitSearch.toLowerCase()) ||
                        acc.accountType.toLowerCase().includes(debitSearch.toLowerCase())
                      )
                      .map(acc => (
                        <option key={acc.id} value={acc.id}>
                          {acc.code} - {acc.name} ({acc.accountType})
                        </option>
                      ))}
                  </select>
                  {activeTab === 'JOURNAL' && (
                    <div className="mt-2">
                      <label className="block text-[11px] font-semibold uppercase text-gray-500 mb-1">Debit Narration</label>
                      <input
                        type="text"
                        required
                        placeholder="Debit account narration..."
                        value={debitNarration}
                        onChange={e => setDebitNarration(e.target.value)}
                        className="w-full rounded-lg border border-gray-300 px-3 py-1.5 text-xs focus:border-emerald-600 focus:outline-hidden"
                      />
                    </div>
                  )}
                </>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold uppercase text-gray-600">
                  {activeTab === 'CASH_PAYMENT' ? 'Credit Account (Fixed Cash in Hand)' : activeTab === 'CASH_RECEIPT' ? 'Credit Account (Received From)' : 'Credit Account'}
                </label>
                {activeTab !== 'CASH_PAYMENT' && (
                  <label className="flex items-center space-x-1.5 text-xs text-emerald-700 cursor-pointer font-medium" title="Fix this credit account for rapid repetitive postings">
                    <input
                      type="checkbox"
                      checked={isCreditFixed}
                      onChange={handleToggleFixCredit}
                      className="rounded border-gray-300 text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                    />
                    <span>Fix Account</span>
                  </label>
                )}
              </div>
              {activeTab === 'CASH_PAYMENT' ? (
                <input
                  type="text"
                  disabled
                  value={(() => {
                    const cAcc = accounts.find(a => a.id === creditAccountId || a.code === 'ACC-10000');
                    return cAcc ? `${cAcc.code} - ${cAcc.name}` : 'ACC-10000 - CASH IN HAND';
                  })()}
                  className="w-full rounded-lg border border-gray-300 bg-gray-100 px-3 py-2 text-sm font-semibold text-gray-800"
                />
              ) : (
                <>
                  <input
                    type="text"
                    placeholder="Search credit account..."
                    value={creditSearch}
                    onChange={e => setCreditSearch(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 px-3 py-1.5 text-xs mb-2 focus:border-emerald-600 focus:outline-hidden"
                  />
                  <select
                    required
                    value={creditAccountId}
                    onChange={e => {
                      const accId = e.target.value;
                      setCreditAccountId(accId);
                      if (isCreditFixed && accId) {
                        localStorage.setItem(`ittehad_fixed_credit_acc_${activeTab}`, accId);
                      }
                      if (activeTab === 'JOURNAL' && accId) {
                        const selAcc = accounts.find(a => a.id === accId);
                        const debAcc = accounts.find(a => a.id === debitAccountId);
                        if (selAcc) {
                          setCreditNarration(`Tr.  to.${selAcc.name}from. ${debAcc ? debAcc.name : ''}`);
                        }
                      }
                    }}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
                  >
                    <option value="">Select Credit Account...</option>
                    {accounts
                      .filter(acc =>
                        acc.name.toLowerCase().includes(creditSearch.toLowerCase()) ||
                        acc.code.toLowerCase().includes(creditSearch.toLowerCase()) ||
                        acc.accountType.toLowerCase().includes(creditSearch.toLowerCase())
                      )
                      .map(acc => (
                        <option key={acc.id} value={acc.id}>
                          {acc.code} - {acc.name} ({acc.accountType})
                        </option>
                      ))}
                  </select>
                  {activeTab === 'JOURNAL' && (
                    <div className="mt-2">
                      <label className="block text-[11px] font-semibold uppercase text-gray-500 mb-1">Credit Narration</label>
                      <input
                        type="text"
                        required
                        placeholder="Credit account narration..."
                        value={creditNarration}
                        onChange={e => setCreditNarration(e.target.value)}
                        className="w-full rounded-lg border border-gray-300 px-3 py-1.5 text-xs focus:border-emerald-600 focus:outline-hidden"
                      />
                    </div>
                  )}
                </>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-gray-600 mb-1">Amount (PKR)</label>
              <input
                ref={amountInputRef}
                type="number"
                step="0.01"
                required
                min="0.01"
                placeholder="0.00"
                value={amount || ''}
                onChange={e => setAmount(Number(e.target.value))}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden font-bold text-emerald-800"
              />
            </div>
          </div>

          <div className="flex items-center justify-between bg-gray-50 p-4 rounded-xl border border-gray-200">
            <div className="flex space-x-6 text-sm">
              <p>Debit Amount: <span className="font-bold text-gray-800">PKR {amount.toLocaleString()}</span></p>
              <p>Credit Amount: <span className="font-bold text-gray-800">PKR {amount.toLocaleString()}</span></p>
              <p className="font-semibold text-emerald-700">(Balanced 2-Entry Voucher)</p>
            </div>
            <button
              type="submit"
              className={`flex items-center space-x-2 ${
                editingVoucher ? 'bg-amber-600 hover:bg-amber-700' : 'bg-emerald-700 hover:bg-emerald-800'
              } text-white px-6 py-2.5 rounded-lg text-sm font-semibold shadow-sm transition-colors`}
            >
              <Save className="w-4 h-4" />
              <span>{editingVoucher ? 'Update Voucher' : 'Post Voucher'}</span>
            </button>
          </div>
        </div>
      </form>

      {/* Date-Wise Search & Filter Panel */}
      {(() => {
        const setQuickDate = (type: 'today' | 'yesterday' | '7days' | 'thisMonth' | 'all') => {
          const now = new Date();
          const todayStr = now.toISOString().split('T')[0];

          if (type === 'today') {
            setFilterStartDate(todayStr);
            setFilterEndDate(todayStr);
          } else if (type === 'yesterday') {
            const yest = new Date(now);
            yest.setDate(yest.getDate() - 1);
            const yestStr = yest.toISOString().split('T')[0];
            setFilterStartDate(yestStr);
            setFilterEndDate(yestStr);
          } else if (type === '7days') {
            const past = new Date(now);
            past.setDate(past.getDate() - 6);
            setFilterStartDate(past.toISOString().split('T')[0]);
            setFilterEndDate(todayStr);
          } else if (type === 'thisMonth') {
            const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
            setFilterStartDate(firstDay);
            setFilterEndDate(todayStr);
          } else if (type === 'all') {
            setFilterStartDate('');
            setFilterEndDate('');
            setSearchKeyword('');
          }
        };

        const filteredVouchers = vouchers.filter(v => {
          const vDate = v.date ? v.date.split('T')[0] : '';
          if (filterStartDate && vDate < filterStartDate) return false;
          if (filterEndDate && vDate > filterEndDate) return false;
          if (searchKeyword.trim()) {
            const q = searchKeyword.toLowerCase().trim();
            const matchNo = v.voucherNo.toLowerCase().includes(q);
            const matchNarration = (v.narration || '').toLowerCase().includes(q);
            const matchStaff = (v.salesStaff || '').toLowerCase().includes(q);
            const matchCreator = (v.createdBy || '').toLowerCase().includes(q);
            const matchLines = v.lines?.some(l =>
              (l.accountName || '').toLowerCase().includes(q) ||
              (l.description || '').toLowerCase().includes(q)
            );
            if (!matchNo && !matchNarration && !matchStaff && !matchCreator && !matchLines) {
              return false;
            }
          }
          return true;
        });

        const filteredTotalAmount = filteredVouchers.reduce((sum, v) => sum + Number(v.totalAmount || 0), 0);
        const isFilterActive = Boolean(filterStartDate || filterEndDate || searchKeyword);

        return (
          <>
            {/* Filter Controls Card */}
            <div className="bg-white rounded-xl border border-gray-200 shadow-xs p-5 space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-gray-100 pb-3">
                <div>
                  <h3 className="text-base font-bold text-gray-800 flex items-center space-x-2">
                    <Calendar className="w-5 h-5 text-emerald-700" />
                    <span>Search & Filter {activeTab.replace('_', ' ')} Vouchers</span>
                  </h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    Filter vouchers date-wise, or search by voucher number, narration, party, or staff
                  </p>
                </div>

                {/* Quick Date Presets */}
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  <span className="text-gray-400 font-semibold text-[11px] uppercase mr-1">Quick:</span>
                  <button
                    type="button"
                    onClick={() => setQuickDate('today')}
                    className="px-2.5 py-1 rounded-md bg-gray-100 hover:bg-emerald-50 hover:text-emerald-800 text-gray-700 font-medium transition-colors border border-gray-200"
                  >
                    Today
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickDate('yesterday')}
                    className="px-2.5 py-1 rounded-md bg-gray-100 hover:bg-emerald-50 hover:text-emerald-800 text-gray-700 font-medium transition-colors border border-gray-200"
                  >
                    Yesterday
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickDate('7days')}
                    className="px-2.5 py-1 rounded-md bg-gray-100 hover:bg-emerald-50 hover:text-emerald-800 text-gray-700 font-medium transition-colors border border-gray-200"
                  >
                    Last 7 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => setQuickDate('thisMonth')}
                    className="px-2.5 py-1 rounded-md bg-gray-100 hover:bg-emerald-50 hover:text-emerald-800 text-gray-700 font-medium transition-colors border border-gray-200"
                  >
                    This Month
                  </button>
                  {isFilterActive && (
                    <button
                      type="button"
                      onClick={() => setQuickDate('all')}
                      className="flex items-center space-x-1 px-2.5 py-1 rounded-md bg-red-50 hover:bg-red-100 text-red-700 font-semibold transition-colors border border-red-200"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Reset</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Date Inputs & Search Bar Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 items-end">
                <div>
                  <label className="block text-xs font-semibold uppercase text-gray-600 mb-1 flex items-center space-x-1">
                    <Calendar className="w-3.5 h-3.5 text-gray-400" />
                    <span>From Date</span>
                  </label>
                  <input
                    type="date"
                    value={filterStartDate}
                    onChange={e => setFilterStartDate(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-gray-600 mb-1 flex items-center space-x-1">
                    <Calendar className="w-3.5 h-3.5 text-gray-400" />
                    <span>To Date</span>
                  </label>
                  <input
                    type="date"
                    value={filterEndDate}
                    onChange={e => setFilterEndDate(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-emerald-600 focus:outline-hidden bg-white"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold uppercase text-gray-600 mb-1 flex items-center space-x-1">
                    <Search className="w-3.5 h-3.5 text-gray-400" />
                    <span>Search Voucher # / Account / Narration</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search by voucher #, account name, narration, staff..."
                      value={searchKeyword}
                      onChange={e => setSearchKeyword(e.target.value)}
                      className="w-full rounded-lg border border-gray-300 pl-9 pr-8 py-2 text-sm focus:border-emerald-600 focus:outline-hidden"
                    />
                    <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                    {searchKeyword && (
                      <button
                        type="button"
                        onClick={() => setSearchKeyword('')}
                        className="absolute right-2.5 top-2.5 text-gray-400 hover:text-gray-600"
                        title="Clear search keyword"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Summary Stats Row */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
                <div className="flex flex-wrap items-center gap-2 text-gray-600">
                  <span>
                    Showing <strong className="text-gray-900 font-bold">{filteredVouchers.length}</strong> of{' '}
                    <strong className="text-gray-900 font-bold">{vouchers.length}</strong> vouchers
                  </span>
                  {isFilterActive && (
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800">
                      Active: {filterStartDate ? `From ${filterStartDate}` : ''} {filterEndDate ? `To ${filterEndDate}` : ''} {searchKeyword ? `"${searchKeyword}"` : ''}
                    </span>
                  )}
                </div>
                <div className="text-sm font-semibold text-gray-800">
                  Total Amount: <span className="font-mono font-bold text-emerald-800">PKR {filteredTotalAmount.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Vouchers Table */}
            <div className="bg-white rounded-xl border border-gray-200 shadow-xs p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-gray-800">
                  Recent {activeTab.replace('_', ' ')} Vouchers ({filteredVouchers.length})
                </h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-gray-200 text-xs font-semibold uppercase text-gray-500 bg-gray-50">
                      <th className="py-3 px-4">Voucher No</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Narration</th>
                      <th className="py-3 px-4 text-right">Amount (PKR)</th>
                      <th className="py-3 px-4">Created By</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 text-sm">
                    {filteredVouchers.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="text-center py-10 text-gray-400">
                          {isFilterActive ? (
                            <div className="space-y-2">
                              <p className="font-medium text-gray-600">No vouchers found matching your date or search filters.</p>
                              <button
                                type="button"
                                onClick={() => setQuickDate('all')}
                                className="inline-flex items-center space-x-1 text-xs text-emerald-700 hover:text-emerald-800 underline font-semibold"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                <span>Clear all filters</span>
                              </button>
                            </div>
                          ) : (
                            'No vouchers recorded for this type.'
                          )}
                        </td>
                      </tr>
                    ) : (
                      filteredVouchers.map(v => (
                        <tr key={v.id} className="hover:bg-gray-50/50">
                          <td className="py-3 px-4 font-mono font-bold text-emerald-800">{v.voucherNo}</td>
                          <td className="py-3 px-4 text-gray-600 font-mono text-xs">{formatDate(v.date)}</td>
                          <td className="py-3 px-4 font-medium text-gray-800">{v.narration}</td>
                          <td className="py-3 px-4 text-right font-bold text-gray-900">{v.totalAmount.toLocaleString()}</td>
                          <td className="py-3 px-4 text-xs text-gray-500">{v.createdBy}</td>
                          <td className="py-3 px-4 text-right space-x-2">
                            <button
                              type="button"
                              onClick={() => handlePrintVoucher(v)}
                              className="p-1.5 text-gray-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg cursor-pointer"
                              title="Print to Default Printer"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleExportVoucherPdf(v)}
                              className="p-1.5 text-gray-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg cursor-pointer"
                              title="Download PDF matching print layout"
                            >
                              <Download className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleEdit(v)}
                              className="p-1.5 text-gray-500 hover:text-amber-700 hover:bg-amber-50 rounded-lg"
                              title="Edit / Amend"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            {currentUser.role === 'ADMIN' && (
                              <button
                                onClick={() => handleDelete(v.id)}
                                className="p-1.5 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                                title="Delete"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        );
      })()}
    </div>
  );
};
