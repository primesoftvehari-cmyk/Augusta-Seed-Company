import React, { useState, useEffect } from 'react';
import { UserProfile, CompanyProfileData, DatabaseStatus } from '../types';
import { db } from '../services/db';
import { LogOut, Database, Shield, User as UserIcon, CheckCircle2, AlertCircle } from 'lucide-react';

interface NavbarProps {
  currentUser: UserProfile;
  companyProfile: CompanyProfileData;
  onLogout: () => void;
  onOpenMySQLModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentUser, companyProfile, onLogout, onOpenMySQLModal }) => {
  const [dbStatus, setDbStatus] = useState<DatabaseStatus>({ type: 'local', connected: false });

  useEffect(() => {
    checkStatus();
  }, []);

  const checkStatus = async () => {
    const s = await db.getDatabaseStatus();
    setDbStatus(s);
  };

  return (
    <header className="bg-emerald-950 text-white shadow-md sticky top-0 z-30 border-b border-emerald-900">
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center space-x-3">
          <div className="w-11 h-11 rounded-xl bg-white flex items-center justify-center border-2 border-emerald-600 shadow-inner overflow-hidden p-0.5">
            <img
              src={companyProfile.logoUrl || '/logoittehad.png'}
              alt="Ittehad Seed Corporation"
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
              onError={(e) => {
                // Fallback to text logo if image fails
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <div>
            <h1 className="text-base font-black tracking-wider uppercase text-white flex items-center space-x-2">
              <span>{companyProfile.companyName || 'ITTEHAD SEED CORPORATION'}</span>
            </h1>
            <p className="text-xs text-emerald-300 font-medium">
              {companyProfile.headOfficeAddress || 'Qaboola Road Arifwala'} | PH: {companyProfile.phone || '03216533233'}
            </p>
          </div>
        </div>

        {/* Actions & User */}
        <div className="flex items-center space-x-3">
          <button
            onClick={onOpenMySQLModal}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              dbStatus.connected
                ? 'bg-emerald-800 text-emerald-100 border-emerald-600 shadow-xs'
                : 'bg-emerald-900/80 text-emerald-200 border-emerald-700 hover:bg-emerald-800'
            }`}
            title="Configure MySQL Backend Database"
          >
            <Database className="w-3.5 h-3.5 text-emerald-300" />
            <span>{dbStatus.connected ? 'MySQL Connected' : 'MySQL Setup'}</span>
            {dbStatus.connected ? (
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            ) : (
              <span className="w-2 h-2 rounded-full bg-amber-400"></span>
            )}
          </button>

          <div className="flex items-center space-x-2 bg-emerald-900/60 px-3 py-1.5 rounded-lg border border-emerald-800/80">
            {currentUser.role === 'ADMIN' ? (
              <Shield className="w-4 h-4 text-amber-400" />
            ) : (
              <UserIcon className="w-4 h-4 text-emerald-300" />
            )}
            <div className="text-left">
              <p className="text-xs font-bold leading-tight">{currentUser.fullName}</p>
              <p className="text-[10px] text-emerald-300 uppercase tracking-wider font-mono">{currentUser.role}</p>
            </div>
          </div>

          <button
            onClick={onLogout}
            className="flex items-center space-x-1 px-3 py-1.5 bg-red-700/80 hover:bg-red-700 text-white rounded-lg text-xs font-semibold transition-colors"
            title="Sign Out"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </div>
    </header>
  );
};
