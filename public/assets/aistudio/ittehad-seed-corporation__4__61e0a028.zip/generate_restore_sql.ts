import fs from 'fs';
import path from 'path';

const jsonPath = path.resolve(process.cwd(), 'public/assets/aistudio/vch_0558a3b3.json');
const outSqlPath = path.resolve(process.cwd(), 'restore_vouchers.sql');

try {
  let raw = fs.readFileSync(jsonPath, 'utf-8').trim();
  if (raw.endsWith(',')) {
    raw = raw.slice(0, -1);
  }
  if (!raw.startsWith('{')) {
    if (!raw.startsWith('"vouchers"')) {
      raw = '{"vouchers": ' + raw + '}';
    } else {
      raw = '{' + raw + '}';
    }
  }

  const data = JSON.parse(raw);
  const vouchers = data.vouchers || [];

  console.log(`Successfully parsed ${vouchers.length} vouchers.`);

  let sql = `-- ========================================================\n`;
  sql += `-- Restore Vouchers into MySQL Table 'vouchers'\n`;
  sql += `-- ========================================================\n\n`;
  sql += `SET NAMES utf8mb4;\n`;
  sql += `USE \`ittehadseed-35303437efb4\`;\n\n`;

  vouchers.forEach((v: any) => {
    const id = v.id || `vch_${Date.now()}_${Math.floor(Math.random()*1000)}`;
    const voucherNo = (v.voucherNo || '').replace(/'/g, "''");
    const voucherType = v.voucherType || 'JOURNAL';
    const date = v.date || new Date().toISOString().split('T')[0];
    const salesStaff = v.salesStaff ? `'${v.salesStaff.replace(/'/g, "''")}'` : 'NULL';
    const lines = JSON.stringify(v.lines || []).replace(/'/g, "''");
    const totalAmount = Number(v.totalAmount || 0);
    const narration = v.narration ? `'${v.narration.replace(/'/g, "''")}'` : 'NULL';
    const createdBy = v.createdBy ? `'${v.createdBy.replace(/'/g, "''")}'` : `'System Administrator'`;
    const createdAt = v.createdAt ? `'${v.createdAt.replace('T', ' ').replace('Z', '')}'` : 'NOW()';

    sql += `INSERT INTO \`vouchers\` (\`id\`, \`voucher_no\`, \`voucher_type\`, \`date\`, \`sales_staff\`, \`lines\`, \`total_amount\`, \`narration\`, \`created_by\`, \`created_at\`) VALUES\n`;
    sql += `('${id}', '${voucherNo}', '${voucherType}', '${date}', ${salesStaff}, '${lines}', ${totalAmount}, ${narration}, ${createdBy}, ${createdAt})\n`;
    sql += `ON DUPLICATE KEY UPDATE \`voucher_no\` = VALUES(\`voucher_no\`), \`lines\` = VALUES(\`lines\`), \`total_amount\` = VALUES(\`total_amount\`);\n\n`;
  });

  fs.writeFileSync(outSqlPath, sql, 'utf-8');
  console.log(`Successfully generated SQL restore script at ${outSqlPath}`);
} catch (err) {
  console.error('Error generating restore SQL:', err);
}
