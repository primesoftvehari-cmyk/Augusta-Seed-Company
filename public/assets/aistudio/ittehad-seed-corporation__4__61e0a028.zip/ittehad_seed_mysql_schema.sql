-- =====================================================================
-- ITTEHAD SEED CORPORATION - MYSQL / PHPMYADMIN DATABASE SCHEMA
-- Address: Qaboola Road Arifwala | Contact: 03216533233
-- Compatible with MySQL 5.7+, MySQL 8.0+, MariaDB 10.3+ & phpMyAdmin
-- =====================================================================

-- Step 1: Create and select the database
CREATE DATABASE IF NOT EXISTS `ittehadseed-35303437efb4`
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE `ittehadseed-35303437efb4`;

-- ---------------------------------------------------------------------
-- Table 1: company_profile
-- Stores company details, contact information, branding, and update timestamp
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `company_profile` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `company_name` VARCHAR(255) NOT NULL,
  `head_office_address` TEXT DEFAULT NULL,
  `phone` VARCHAR(100) DEFAULT NULL,
  `mobile` VARCHAR(100) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `website` VARCHAR(100) DEFAULT NULL,
  `ntn` VARCHAR(100) DEFAULT NULL,
  `strn` VARCHAR(100) DEFAULT NULL,
  `logo_url` LONGTEXT DEFAULT NULL,
  `financial_year` VARCHAR(50) DEFAULT '2026-2027',
  `invoice_footer` TEXT DEFAULT NULL,
  `report_footer` TEXT DEFAULT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 2: users
-- User accounts with role-based access control (Admin / User)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `full_name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(150) DEFAULT NULL,
  `mobile` VARCHAR(100) DEFAULT NULL,
  `role` VARCHAR(50) NOT NULL DEFAULT 'USER',
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `permissions` JSON NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 3: accounts
-- General ledger accounts (Assets, Liabilities, Equity, Revenue, Expenses)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `accounts` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `name` VARCHAR(255) NOT NULL,
  `parent_account` VARCHAR(255) DEFAULT NULL,
  `account_type` ENUM('Assets', 'Liabilities', 'Equity', 'Revenue', 'Expenses', 'General Ledgers') NOT NULL,
  `sales_staff` VARCHAR(255) DEFAULT NULL,
  `phone` VARCHAR(100) DEFAULT NULL,
  `opening_balance` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `opening_balance_type` ENUM('Dr', 'Cr') NOT NULL DEFAULT 'Dr',
  `description` TEXT DEFAULT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_accounts_type` (`account_type`),
  INDEX `idx_accounts_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 4: sales_staff
-- Sales representatives & field officers with joining date
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sales_staff` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `staff_code` VARCHAR(50) NOT NULL UNIQUE,
  `staff_name` VARCHAR(255) NOT NULL,
  `father_name` VARCHAR(255) DEFAULT NULL,
  `mobile` VARCHAR(100) DEFAULT NULL,
  `whatsapp` VARCHAR(100) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `territory` VARCHAR(150) DEFAULT NULL,
  `joining_date` DATE DEFAULT NULL,
  `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  `remarks` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_staff_code` (`staff_code`),
  INDEX `idx_staff_date` (`joining_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 5: territories
-- Geographic distribution zones and cities
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `territories` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `territory_code` VARCHAR(50) NOT NULL UNIQUE,
  `territory_name` VARCHAR(255) NOT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `district` VARCHAR(100) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `status` ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_territory_code` (`territory_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 6: products
-- Seed varieties, packaging sizes, rates, and stock thresholds
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `product_code` VARCHAR(50) NOT NULL UNIQUE,
  `product_name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) DEFAULT 'Seeds',
  `variety` VARCHAR(100) DEFAULT NULL,
  `unit` VARCHAR(50) DEFAULT 'Kgs',
  `pack_size` VARCHAR(50) DEFAULT 'Single',
  `purchase_rate` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `sale_rate` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `opening_stock` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `opening_stock_rate` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `minimum_stock` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `description` TEXT DEFAULT NULL,
  `active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_product_code` (`product_code`),
  INDEX `idx_product_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 7: vouchers
-- Cash Payment (CPV), Cash Receipt (CRV), and Journal Vouchers (JV)
-- Contains voucher date (DATE) and creation timestamp (TIMESTAMP)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `vouchers` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `voucher_no` VARCHAR(100) NOT NULL UNIQUE,
  `voucher_type` ENUM('CASH_PAYMENT', 'CASH_RECEIPT', 'JOURNAL') NOT NULL,
  `date` DATE NOT NULL,
  `sales_staff` VARCHAR(255) DEFAULT NULL,
  `lines` JSON NOT NULL,
  `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `narration` TEXT DEFAULT NULL,
  `created_by` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_voucher_date` (`date`),
  INDEX `idx_voucher_type` (`voucher_type`),
  INDEX `idx_voucher_no` (`voucher_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Table 8: invoices
-- Sales, Purchases, Sales Returns, and Purchase Returns
-- Contains invoice date (DATE) and creation timestamp (TIMESTAMP)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `invoice_no` VARCHAR(100) NOT NULL UNIQUE,
  `invoice_type` ENUM('SALES_CREDIT', 'SALES_CASH', 'PURCHASE_CREDIT', 'PURCHASE_CASH', 'SALES_RETURN', 'PURCHASE_RETURN') NOT NULL,
  `date` DATE NOT NULL,
  `account_name` VARCHAR(255) NOT NULL,
  `sales_staff` VARCHAR(255) DEFAULT NULL,
  `territory` VARCHAR(150) DEFAULT NULL,
  `original_invoice_no` VARCHAR(100) DEFAULT NULL,
  `reason` TEXT DEFAULT NULL,
  `items` JSON NOT NULL,
  `gross_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `discount_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `net_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `remarks` TEXT DEFAULT NULL,
  `created_by` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_invoice_date` (`date`),
  INDEX `idx_invoice_type` (`invoice_type`),
  INDEX `idx_invoice_account` (`account_name`),
  INDEX `idx_invoice_no` (`invoice_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- INITIAL SEED DATA
-- Default Company Profile, Admin User & Standard Seed Chart of Accounts
-- =====================================================================

-- 1. Insert Company Profile
INSERT INTO `company_profile` (
  `id`, `company_name`, `head_office_address`, `phone`, `mobile`,
  `email`, `website`, `ntn`, `strn`, `logo_url`, `financial_year`,
  `invoice_footer`, `report_footer`
) VALUES (
  'default',
  'Ittehad Seed Corporation',
  'Qaboola Road Arifwala',
  '03216533233',
  '03216533233',
  'info@ittehadseed.com',
  'www.ittehadseed.com',
  '3216533-2',
  '32-16-5332-330-01',
  '/logoittehad.png',
  '2026-2027',
  'Quality Seeds Guaranteed. Goods once sold will not be returned without warranty inspection.',
  'Computer generated official document. Ittehad Seed Corporation Arifwala.'
) ON DUPLICATE KEY UPDATE `company_name` = VALUES(`company_name`);

-- 2. Insert Default Admin User
INSERT INTO `users` (
  `id`, `username`, `full_name`, `email`, `mobile`, `role`, `active`, `permissions`
) VALUES (
  'usr_admin_01',
  'admin',
  'System Administrator',
  'admin@ittehadseed.com',
  '03216533233',
  'ADMIN',
  1,
  '{"canManageUsers": true, "canManageAccounts": true, "canManageProducts": true, "canManageStaff": true, "canManageTerritories": true, "canManageCompany": true, "canCreateVouchers": true, "canCreateInvoices": true, "canViewReports": true, "canEditDelete": true}'
) ON DUPLICATE KEY UPDATE `full_name` = VALUES(`full_name`);

-- 3. Insert Standard Chart of Accounts
INSERT INTO `accounts` (
  `id`, `code`, `name`, `account_type`, `opening_balance`, `opening_balance_type`, `description`
) VALUES
  ('acc_1', '1010', 'Cash in Hand', 'Assets', 150000.00, 'Dr', 'Main company cash office - Arifwala'),
  ('acc_2', '1020', 'Habib Bank Limited (Arifwala Branch)', 'Assets', 450000.00, 'Dr', 'Primary operational bank account'),
  ('acc_3', '2010', 'Sundry Debtors / Farmers Receivable', 'Assets', 0.00, 'Dr', 'Seed dealers & farmers credit account'),
  ('acc_4', '3010', 'Seed Growers & Suppliers Payable', 'Liabilities', 0.00, 'Cr', 'Seed growers procurement payables'),
  ('acc_5', '4010', 'Seed Sales Revenue', 'Revenue', 0.00, 'Cr', 'Revenue from certified crop seeds sales'),
  ('acc_6', '5010', 'Seed Procurement & Production Cost', 'Expenses', 0.00, 'Dr', 'Seed processing, packaging and grading costs')
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- 4. Sample Territory
INSERT INTO `territories` (
  `id`, `territory_code`, `territory_name`, `city`, `district`, `description`, `status`
) VALUES
  ('ter_01', 'TER-01', 'Arifwala Central', 'Arifwala', 'Pakpattan', 'Primary head office distribution zone', 'Active'),
  ('ter_02', 'TER-02', 'Qaboola Zone', 'Qaboola', 'Pakpattan', 'Agricultural farm belt zone', 'Active')
ON DUPLICATE KEY UPDATE `territory_name` = VALUES(`territory_name`);

-- 5. Sample Products
INSERT INTO `products` (
  `id`, `product_code`, `product_name`, `category`, `variety`, `unit`, `pack_size`, `purchase_rate`, `sale_rate`, `opening_stock`, `opening_stock_rate`, `minimum_stock`
) VALUES
  ('prd_01', 'WHT-Akbar', 'Wheat Seed (Akbar-19 Certified)', 'Seeds', 'Akbar-19', 'Bag', '50 Kg', 4800.00, 5600.00, 500.00, 4800.00, 50.00),
  ('prd_02', 'CTN-BS15', 'Cotton Hybrid Seed (BS-15)', 'Seeds', 'BS-15', 'Bag', '10 Kg', 2400.00, 3100.00, 300.00, 2400.00, 30.00),
  ('prd_03', 'RIC-Kainat', 'Basmati Rice Seed (Super Kainat)', 'Seeds', 'Super Kainat', 'Bag', '20 Kg', 3200.00, 4000.00, 250.00, 3200.00, 25.00)
ON DUPLICATE KEY UPDATE `product_name` = VALUES(`product_name`);
